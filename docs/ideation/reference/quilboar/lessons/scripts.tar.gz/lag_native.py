"""Rounds-late at R12 for the wave-1 native lines, from docs/ideation/evidence/wave1-accounting.md
(authored paper at R8/R10/R12/R14, real pre-start medians), beside Quilboar's from lag.py.
Log interpolation between the paper's even rounds. Usage: python3 -I lag_native.py"""
import math
paper = {  # wave1-accounting.md table, 'Paper pre-start'
    'birds_homecoming': {8: 96, 10: 240, 12: 615, 14: 1275},
    'birds_tempo': {8: 106, 10: 159, 12: 361, 14: 894},
    'fairies_ring': {8: 92, 10: 275, 12: 530, 14: 1410},
    'fairies_court': {8: 107, 10: 389, 12: 945, 14: 1325},
}
real12 = {'birds_homecoming': 270, 'birds_tempo': 260.5, 'fairies_ring': 142, 'fairies_court': 160}
def at(c, x):
    rs = sorted(c)
    for a, b in zip(rs, rs[1:]):
        if c[a] <= x <= c[b]:
            return a + (b - a) * (math.log(x / c[a]) / math.log(c[b] / c[a]))
    return None
for k, c in paper.items():
    r = at(c, real12[k])
    lo = at(c, 0.5 * c[12])
    print(f'{k:17s} R12 real {real12[k]:>6} paper {c[12]:>4} ratio {real12[k]/c[12]:.3f}  equals paper R{r:.2f} -> {12-r:.2f} rounds late; band tolerates {12-lo:.2f} rounds late')
