"""Load the committed Quilboar H1 compact archives (read-only) into per-seat trajectories."""
import glob
import gzip
import json
import os
import random
import statistics

EV = "/home/alex/code/Bramble-ideation-sol/tools/sim/evidence"
ARMS = {
    # canonical arms used by h1.md
    "B": f"{EV}/quilboar-h1-cycle-fix/B",
    "C": f"{EV}/quilboar-h1/C",
    "uncut": f"{EV}/quilboar-h1-cycle-fix/uncut",
    "uncut_frozen": f"{EV}/quilboar-h1/uncut_frozen",
    # superseded pre-fix arms, used only for like-for-like comparisons
    "B_pre": f"{EV}/quilboar-h1/B",
    "uncut_pre": f"{EV}/quilboar-h1/uncut",
}
LINES = [
    "line_quilboar_engine", "line_birds_homecoming", "line_fairies_ring", "line_bog_engine",
    "line_hedgerow_engine", "line_hunters_engine", "line_oozes_engine", "hard",
]
SHORT = {
    "line_quilboar_engine": "Quilboar", "line_birds_homecoming": "Birds", "line_fairies_ring": "Fairies",
    "line_bog_engine": "Bog", "line_hedgerow_engine": "Hedgerow", "line_hunters_engine": "Hunters",
    "line_oozes_engine": "Oozes", "hard": "Hard",
}


def load(arm):
    lobbies = []
    for path in sorted(glob.glob(os.path.join(ARMS[arm], "*.lobbies.json.gz"))):
        for game in json.load(gzip.open(path)):
            seats = {}
            for p in game["players"]:
                seats[p["seat"]] = {
                    "seat": p["seat"], "line": p["line"], "place": p["place"], "rounds": p["rounds"],
                    "board": {}, "post": {}, "units": {}, "tier": {}, "keystone": None, "gem": {},
                    "share": {},
                }
            for r in game["rounds"]:
                s = seats[r["seat"]]
                n = r["round"]
                s["board"][n] = r["stats"]
                s["post"][n] = r["post_start_stats"]
                s["units"][n] = [u["id"] for u in r["units"]]
                s["tier"][n] = r["tier"]
                s["gem"][n] = r["gem_size"]
                s["share"][n] = r["largest_share"]
                k = r.get("keystone_found_round")
                if k is not None and k > 0:
                    s["keystone"] = k if s["keystone"] is None else min(s["keystone"], k)
            lobbies.append({"seed": game["seed"], "arm": game["arm"], "seats": list(seats.values())})
    return lobbies


def med(xs):
    return statistics.median(xs) if xs else None


def boot(lobbies, fn, reps=2000, seed=481516):
    """Whole-lobby seed bootstrap, 95% percentile interval."""
    rng = random.Random(seed)
    vals = []
    n = len(lobbies)
    for _ in range(reps):
        sample = [lobbies[rng.randrange(n)] for _ in range(n)]
        v = fn(sample)
        if v is not None:
            vals.append(v)
    vals.sort()
    if not vals:
        return (None, None)
    return (vals[int(0.025 * len(vals))], vals[min(len(vals) - 1, int(0.975 * len(vals)))])


def seats_of(lobbies, line=None, exclude=()):
    for lob in lobbies:
        for s in lob["seats"]:
            if line is not None and s["line"] != line:
                continue
            if s["line"] in exclude:
                continue
            yield s


def surv_median(lobbies, rnd, line=None, exclude=()):
    return med([s["board"][rnd] for s in seats_of(lobbies, line, exclude) if rnd in s["board"]])


def itt_median(lobbies, rnd, line):
    """Median over all seats of the line, eliminated seats ranked lowest (0)."""
    vals = [s["board"].get(rnd, 0) for s in seats_of(lobbies, line)]
    return med(vals)


def growth(a, b, rounds):
    if a is None or b is None or a <= 0 or b <= 0:
        return None
    return (b / a) ** (1 / rounds)
