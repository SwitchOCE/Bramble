"""Follow-up checks. Run: python3 -I q_followup.py > out_followup.txt (needs fights.pkl from q_captures.py)"""
import os
import pickle
import sys
from collections import Counter, defaultdict

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from load import ARMS, CANON, LINES, SHORT, load_arm, median, pct, seat_rounds  # noqa: E402

SCR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
with open(os.path.join(SCR, "fights.pkl"), "rb") as fh:
    fights, _ = pickle.load(fh)
Q = "line_quilboar_engine"


def score(f, side):
    w = f["winner"]
    return 1.0 if w == side else (0.0 if w in (0, 1) else 0.5)


print("== Q4 check: equal totals on POST-start stats (after Start of Combat effects), R9+")
for k in CANON:
    def eqp(f, i):
        a, b = f["post"][i], f["post"][1 - i]
        return b > 0 and 0.8 <= a / b <= 1.25
    qs = [score(f, f["lines"].index(Q)) for f in fights[k] if f["round"] >= 9 and Q in f["lines"] and eqp(f, f["lines"].index(Q))]
    nn = []
    for f in fights[k]:
        if f["round"] >= 9 and Q not in f["lines"] and eqp(f, 0):
            nn.append(score(f, 0))
    print(f"  {k:11s} Quilboar win at equal post-start totals {sum(qs) / len(qs):.2f} (n={len(qs)}); native-native side 0 at equal totals {sum(nn) / len(nn):.2f} (n={len(nn)})")
    # how much do natives gain at start of combat compared with Quilboar
    gq = [f["post"][i] / f["stats"][i] for f in fights[k] if f["round"] >= 12 for i in range(2) if f["lines"][i] == Q and f["stats"][i] > 0]
    gn = defaultdict(list)
    for f in fights[k]:
        if f["round"] >= 12:
            for i in range(2):
                if f["lines"][i] != Q and f["stats"][i] > 0:
                    gn[f["lines"][i]].append(f["post"][i] / f["stats"][i])
    print("      post/pre-start ratio R12+ median: Quilboar %.2f; " % median(gq) + ", ".join(f"{SHORT[ln]} {median(v):.2f}" for ln, v in gn.items()))

print("\n== Q4 check: units on board at equal totals (R9+): Quilboar vs opponent median units")
for k in CANON:
    nq, no = [], []
    for f in fights[k]:
        if f["round"] >= 9 and Q in f["lines"]:
            i = f["lines"].index(Q)
            a, b = f["stats"][i], f["stats"][1 - i]
            if b > 0 and 0.8 <= a / b <= 1.25:
                nq.append(f["nunits"][i]); no.append(f["nunits"][1 - i])
    print(f"  {k:11s} Quilboar units {median(nq)}, opponent units {median(no)} (n={len(nq)})")

print("\n== Q2/Q9 check: Hogrider by R12 among Quilboar seats alive at R13 (removes early-death bias)")
DATA = {k: load_arm(k) for k in CANON}
for k in CANON:
    got, miss = [], []
    for l in DATA[k]:
        sr = seat_rounds(l)
        for p in l["players"]:
            if p["line"] != Q:
                continue
            s = p["seat"]
            if 13 not in sr[s]:
                continue
            has = any(u["id"] == "qb_turbo_hogrider" for r in range(1, 13) if r in sr[s] for u in sr[s][r]["units"])
            (got if has else miss).append(p["place"])
    print(f"  {k:11s} alive at R13: n={len(got) + len(miss)}; Hogrider on board by R12 {len(got) / (len(got) + len(miss)):.2f}; mean place with {sum(got) / len(got):.2f} (first {sum(1 for x in got if x == 1) / len(got):.2f}), without {sum(miss) / len(miss):.2f} (first {sum(1 for x in miss if x == 1) / len(miss):.2f})")

print("\n== Q2 check: Quilboar seat health (hero HP) at R12 start, by outcome, and damage taken R9-R11")
for k in CANON:
    hp12 = []
    for l in DATA[k]:
        sr = seat_rounds(l)
        for p in l["players"]:
            if p["line"] == Q and 12 in sr[p["seat"]]:
                hp12.append((sr[p["seat"]][12]["health"], p["place"]))
    print(f"  {k:11s} median hero HP at R12 (alive) {median([h for h, _ in hp12])}; for eventual winners {median([h for h, pl in hp12 if pl == 1])}; others {median([h for h, pl in hp12 if pl > 1])}")

print("\n== Q2 check: Hard's chosen line at R1 (current_line), canonical arms pooled")
c = Counter()
for k in CANON:
    for l in DATA[k]:
        sr = seat_rounds(l)
        for p in l["players"]:
            if p["line"] == "hard":
                c[sr[p["seat"]][1]["current_line"]] += 1
print("  " + ", ".join(f"{a} {b}" for a, b in c.most_common()))

print("\n== Q10 check: native splash-hazard cards ever on the Quilboar seat's board, canonical arms pooled")
HAZ = ["cricket_busker", "pipistrelle_echo", "silky", "stone_soup", "sexton_beetle", "whirligig_beetle"]
n = 0
c = Counter()
anyn = 0
for k in CANON:
    for l in DATA[k]:
        sr = seat_rounds(l)
        for p in l["players"]:
            if p["line"] != Q:
                continue
            n += 1
            held = {u["id"] for r in sr[p["seat"]] for u in sr[p["seat"]][r]["units"] if r >= 8}
            if any(not x.startswith("qb_") for x in held):
                anyn += 1
            for hz in HAZ:
                if hz in {u["id"] for r in sr[p["seat"]] for u in sr[p["seat"]][r]["units"]}:
                    c[hz] += 1
print(f"  Quilboar seats {n}; holding any native unit from R8: {anyn / n:.2f}; hazard cards ever held: " + ", ".join(f"{h} {c[h]}" for h in HAZ))
