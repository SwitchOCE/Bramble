"""Head-to-head lobby fights from the local, gitignored full captures (hash-checked against the committed receipts).

Captures: /home/alex/code/Bramble-ideation-sol/build/quilboar-h1-captures/<run>/<arm>/*.fights.jsonl.gz
Receipts: /home/alex/code/Bramble-ideation-sol/tools/sim/evidence/<run>/<arm>/receipt.json (capture_gzip_sha256 per chunk)
Run: python3 -I q_captures.py > out_captures.txt
"""
import glob
import gzip
import hashlib
import json
import math
import os
import pickle
import sys
from collections import Counter, defaultdict

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from load import EV, LINES, SHORT, median, pct  # noqa: E402

CAP = "/home/alex/code/Bramble-ideation-sol/build/quilboar-h1-captures"
RUNS = {
    "B_pre": ("quilboar-h1", "B"),
    "C_pre": ("quilboar-h1", "C"),
    "uncut_pre": ("quilboar-h1", "uncut"),
    "frozen_pre": ("quilboar-h1", "uncut_frozen"),
    "B_post": ("quilboar-h1-cycle-fix", "B"),
    "uncut_post": ("quilboar-h1-cycle-fix", "uncut"),
}
Q = "line_quilboar_engine"
OUT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "fights.pkl")


def receipts(run, arm):
    with open(f"{EV}/{run}/{arm}/receipt.json") as fh:
        r = json.load(fh)
    return {os.path.basename(c["capture"]): c["capture_gzip_sha256"] for c in r["chunks"]}


def load():
    if os.path.exists(OUT):
        with open(OUT, "rb") as fh:
            return pickle.load(fh)
    fights = {}
    check = {}
    for key, (run, arm) in RUNS.items():
        want = receipts(run, arm)
        ok = bad = missing = 0
        rows = []
        files = sorted(glob.glob(f"{CAP}/{run}/{arm}/*.fights.jsonl.gz"))
        names = {os.path.basename(f) for f in files}
        missing = len(set(want) - names)
        for f in files:
            with open(f, "rb") as fh:
                digest = hashlib.sha256(fh.read()).hexdigest()
            if want.get(os.path.basename(f)) != digest:
                bad += 1
                continue
            ok += 1
            with gzip.open(f, "rt") as fh:
                for line in fh:
                    x = json.loads(line)
                    if -1 in x["players"] or len(x["combat_start"]) < 2:
                        continue
                    cs = x["combat_start"]
                    fr = x["input"]["fight_rules"]
                    rows.append({
                        "seed": x["seed"], "round": x["round"], "players": x["players"],
                        "lines": [c.get("assigned_line") for c in cs],
                        "cur": [c.get("current_line") for c in cs],
                        "stats": [c["active_stats"] for c in cs],
                        "post": [a["active_stats"] for a in x["after_start_effects"]],
                        "share": [c["largest_share"] for c in cs],
                        "nunits": [len(c["units"]) for c in cs],
                        "winner": x["outcome"]["winner"],
                        "damage": x["outcome"]["damage"],
                        "ring": [f.get("ring_size") for f in fr],
                        "rings": [sum(it.get("count", 0) for slot in x["input"]["slots"][i] for it in slot if it.get("name") == "Ring") for i in range(2)],
                        "takes": x["outcome"].get("takes"),
                    })
        fights[key] = rows
        check[key] = {"files_ok": ok, "hash_mismatch": bad, "missing": missing}
    with open(OUT, "wb") as fh:
        pickle.dump((fights, check), fh)
    return fights, check


fights, check = load()
print("Capture hash check against committed receipts:", json.dumps(check))
print("winner values:", dict(Counter(f["winner"] for f in fights["B_post"])))


def score(f, side):
    w = f["winner"]
    if w == side:
        return 1.0
    if w in (0, 1):
        return 0.0
    return 0.5


def band(r):
    if r <= 8:
        return "R6-8"
    if r <= 11:
        return "R9-11"
    if r <= 14:
        return "R12-14"
    return "R15+"


BANDS = ["R6-8", "R9-11", "R12-14", "R15+"]
CANON = ["B_post", "C_pre", "uncut_post", "frozen_pre"]

print("\n== Q4/Q5. Quilboar's win rate in lobby fights against each line, by round band (draws = 1/2; n fights)")
for k in CANON + ["uncut_pre", "B_pre"]:
    print(f"  {k}")
    for opp in LINES[1:]:
        cells = []
        for b in BANDS:
            s = [score(f, f["lines"].index(Q)) for f in fights[k] if f["round"] >= 6 and band(f["round"]) == b and Q in f["lines"] and opp in f["lines"] and opp != Q]
            cells.append(f"{b} {sum(s) / len(s):.2f} (n={len(s)})" if s else f"{b} -")
        print(f"    vs {SHORT[opp]:9s} " + "  ".join(cells))

print("\n== Q4. Wide against tall at near-equal totals (0.8 <= own/opp pre-start stats <= 1.25), R9+")


def eq(f, i):
    a, b = f["stats"][i], f["stats"][1 - i]
    return b > 0 and 0.8 <= a / b <= 1.25


for k in CANON:
    print(f"  {k}")
    qs = [score(f, f["lines"].index(Q)) for f in fights[k] if f["round"] >= 9 and Q in f["lines"] and eq(f, f["lines"].index(Q))]
    print(f"    Quilboar vs any native at equal totals: win {sum(qs) / len(qs):.2f} (n={len(qs)})")
    for opp in LINES[1:]:
        s = [score(f, f["lines"].index(Q)) for f in fights[k] if f["round"] >= 9 and Q in f["lines"] and opp in f["lines"] and eq(f, f["lines"].index(Q))]
        if s:
            print(f"      vs {SHORT[opp]:9s} {sum(s) / len(s):.2f} (n={len(s)})")
    # native-native baseline: wider side's win rate at equal totals
    ww = []
    for f in fights[k]:
        if f["round"] < 9 or Q in f["lines"]:
            continue
        if not eq(f, 0):
            continue
        if abs(f["share"][0] - f["share"][1]) < 0.05:
            continue
        wide = 0 if f["share"][0] < f["share"][1] else 1
        ww.append(score(f, wide))
    print(f"    native vs native, equal totals, shares differ by >=0.05: wider side wins {sum(ww) / len(ww):.2f} (n={len(ww)})")
    # by opponent tallness for Quilboar
    for lo, hi in ((0, 0.3), (0.3, 0.4), (0.4, 1.01)):
        s = [score(f, f["lines"].index(Q)) for f in fights[k] if f["round"] >= 9 and Q in f["lines"] and eq(f, f["lines"].index(Q)) and lo <= f["share"][1 - f["lines"].index(Q)] < hi]
        if s:
            print(f"    Quilboar at equal totals vs opponent biggest-unit share {lo:.1f}-{hi:.1f}: win {sum(s) / len(s):.2f} (n={len(s)})")

print("\n== Q4. Bog and Hunters (enemy-borrowing lines) at equal totals: vs Quilboar against vs other natives, R9+")
for k in CANON:
    for me in ("line_bog_engine", "line_hunters_engine", "line_birds_homecoming", "line_fairies_ring"):
        vq = [score(f, f["lines"].index(me)) for f in fights[k] if f["round"] >= 9 and me in f["lines"] and Q in f["lines"] and eq(f, f["lines"].index(me))]
        vn = [score(f, f["lines"].index(me)) for f in fights[k] if f["round"] >= 9 and me in f["lines"] and Q not in f["lines"] and f["lines"][0] != f["lines"][1] and eq(f, f["lines"].index(me))]
        if vq and vn:
            print(f"  {k:11s} {SHORT[me]:9s} equal totals: vs Quilboar {sum(vq) / len(vq):.2f} (n={len(vq)})   vs other natives {sum(vn) / len(vn):.2f} (n={len(vn)})")

print("\n== Q4. Stat-ratio curve: win rate of the side with more pre-start stats, by ratio bin, R9+ (Quilboar-involved vs native-native)")
BINS = [(1.0, 1.25), (1.25, 1.5), (1.5, 2.0), (2.0, 4.0), (4.0, 1e9)]
for k in CANON:
    for label, pred in (("Q bigger", lambda f, i: f["lines"][i] == Q), ("Q smaller", lambda f, i: f["lines"][1 - i] == Q), ("native-native", lambda f, i: Q not in f["lines"])):
        cells = []
        for lo, hi in BINS:
            s = []
            for f in fights[k]:
                if f["round"] < 9:
                    continue
                a, b = f["stats"]
                if min(a, b) <= 0:
                    continue
                i = 0 if a >= b else 1
                r = f["stats"][i] / f["stats"][1 - i]
                if lo <= r < hi and pred(f, i):
                    s.append(score(f, i))
            cells.append(f"{lo:g}-{hi if hi < 1e8 else 'inf'}: {sum(s) / len(s):.2f}/{len(s)}" if s else f"{lo:g}-: -")
        print(f"  {k:11s} {label:13s} bigger side wins: " + "  ".join(cells))

print("\n== Q3. Fights decided before they start: share of lobby fights R12-R15 with one board >= 1.5x the other, and the bigger side's win rate")
for k in CANON + ["uncut_pre", "B_pre"]:
    allf = [f for f in fights[k] if 12 <= f["round"] <= 15 and min(f["stats"]) > 0]
    big = [f for f in allf if max(f["stats"]) / min(f["stats"]) >= 1.5]
    wins = [score(f, 0 if f["stats"][0] >= f["stats"][1] else 1) for f in big]
    qf = [f for f in allf if Q in f["lines"]]
    qbig = [f for f in qf if max(f["stats"]) / min(f["stats"]) >= 1.5]
    nn = [f for f in allf if Q not in f["lines"]]
    nnbig = [f for f in nn if max(f["stats"]) / min(f["stats"]) >= 1.5]
    print(f"  {k:11s} all fights: {len(big) / len(allf):.2f} of {len(allf)} lopsided, bigger wins {sum(wins) / len(wins):.2f};  Quilboar fights {len(qbig) / len(qf):.2f} of {len(qf)};  native-only fights {len(nnbig) / len(nn):.2f} of {len(nn)}")

print("\n== Q3. Does a seat's x2 round decide its next fight? Win rate in the fight of the round where pre-start board >= 2x previous round, vs other fights R8+")
for k in CANON:
    # seat-round stats from fights
    by = defaultdict(dict)
    res = defaultdict(dict)
    for f in fights[k]:
        for i in range(2):
            key = (f["seed"], f["players"][i])
            by[key][f["round"]] = f["stats"][i]
            res[key][f["round"]] = (score(f, i), f["lines"][i])
    for line in (Q, "line_birds_homecoming", "line_fairies_ring", "line_hedgerow_engine"):
        jump, other = [], []
        for key, rs in by.items():
            for r, st in rs.items():
                if r < 8 or r not in res[key] or res[key][r][1] != line:
                    continue
                prev = rs.get(r - 1)
                if prev and prev >= 30:
                    (jump if st / prev >= 2 else other).append(res[key][r][0])
        if jump:
            print(f"  {k:11s} {SHORT[line]:9s} x2 round fights: win {sum(jump) / len(jump):.2f} (n={len(jump)})  other fights: {sum(other) / len(other):.2f} (n={len(other)})")

print("\n== Q6. Fairies' Ring size (fight_rules ring_size) and Ring count by round, against Quilboar gem size (compact archive, see out_compact)")
for k in CANON:
    cells = []
    for r in (6, 9, 12, 15):
        rs = [f["ring"][i] for f in fights[k] if f["round"] == r for i in range(2) if f["lines"][i] == "line_fairies_ring" and f["ring"][i] is not None]
        rc = [f["rings"][i] for f in fights[k] if f["round"] == r for i in range(2) if f["lines"][i] == "line_fairies_ring"]
        cells.append(f"R{r} size {median(rs)} (p90 {pct(rs, .9)}), rings {median(rc)} (n={len(rs)})")
    print(f"  {k:11s} " + "; ".join(cells))
