"""Load the committed Quilboar H1 compact archives (read-only) and the run-commit unit library.

Sources (read only):
  /home/alex/code/Bramble-ideation-sol/tools/sim/evidence/quilboar-h1/<arm>/*.lobbies.json.gz      (pre-fix)
  /home/alex/code/Bramble-ideation-sol/tools/sim/evidence/quilboar-h1-cycle-fix/<arm>/*.lobbies.json.gz (post-fix)
  unit library: git archive of bb8bb5f2 (content/units, content/reference/quilboar), extracted to scratch.
"""
import glob
import gzip
import json
import os
import statistics

EV = "/home/alex/code/Bramble-ideation-sol/tools/sim/evidence"
SCR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CONTENT = os.path.join(SCR, "content-bb8bb5f2", "content")

ARMS = {
    "B_pre": (EV + "/quilboar-h1/B", "B"),
    "C_pre": (EV + "/quilboar-h1/C", "C"),
    "uncut_pre": (EV + "/quilboar-h1/uncut", "uncut"),
    "frozen_pre": (EV + "/quilboar-h1/uncut_frozen", "uncut_frozen"),
    "B_post": (EV + "/quilboar-h1-cycle-fix/B", "B"),
    "uncut_post": (EV + "/quilboar-h1-cycle-fix/uncut", "uncut"),
}
# The arms h1.md treats as canonical
CANON = ["B_post", "C_pre", "uncut_post", "frozen_pre"]

LINES = [
    "line_quilboar_engine",
    "line_birds_homecoming",
    "line_fairies_ring",
    "line_bog_engine",
    "line_hedgerow_engine",
    "line_hunters_engine",
    "line_oozes_engine",
    "hard",
]
SHORT = {
    "line_quilboar_engine": "Quilboar",
    "line_birds_homecoming": "Birds",
    "line_fairies_ring": "Fairies",
    "line_bog_engine": "Bog",
    "line_hedgerow_engine": "Hedgerow",
    "line_hunters_engine": "Hunters",
    "line_oozes_engine": "Oozes",
    "hard": "Hard",
}
LINE_TRIBE = {
    "line_quilboar_engine": "quilboar",
    "line_birds_homecoming": "Birds",
    "line_fairies_ring": "Fairies",
    "line_bog_engine": "Bog folk",
    "line_hedgerow_engine": "Hedgerow folk",
    "line_hunters_engine": "Hunters",
    "line_oozes_engine": "Oozes",
}


def load_arm(key):
    folder, _ = ARMS[key]
    lobbies = []
    for f in sorted(glob.glob(folder + "/*.lobbies.json.gz")):
        with gzip.open(f, "rt") as fh:
            lobbies.extend(json.load(fh))
    return lobbies


_UNITS = None


def units():
    global _UNITS
    if _UNITS is None:
        m = {}
        for f in glob.glob(CONTENT + "/units/*.json") + glob.glob(CONTENT + "/reference/quilboar/units/*.json"):
            with open(f) as fh:
                u = json.load(fh)
            tr = u.get("tribes") or []
            if u["id"].startswith("qb_"):
                tr = ["quilboar"]
            m[u["id"]] = {"tier": u.get("tier"), "tribes": tr, "pool": u.get("pool")}
        _UNITS = m
    return _UNITS


def seat_rounds(lobby):
    """{seat: {round: row}}"""
    out = {}
    for r in lobby["rounds"]:
        out.setdefault(r["seat"], {})[r["round"]] = r
    return out


def median(xs):
    return statistics.median(xs) if xs else None


def pct(xs, p):
    xs = sorted(xs)
    if not xs:
        return None
    k = (len(xs) - 1) * p
    lo = int(k)
    hi = min(lo + 1, len(xs) - 1)
    return xs[lo] + (xs[hi] - xs[lo]) * (k - lo)


def fmt(x, nd=1):
    if x is None:
        return "-"
    if isinstance(x, float):
        return f"{x:,.{nd}f}"
    return f"{x:,}"
