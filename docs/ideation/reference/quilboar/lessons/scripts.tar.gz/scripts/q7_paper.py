"""Paper estimate for question 7 (coupling against an axis cut), on a patched scratch copy of qm3.py.
Patch: dial gemday_no_hog=True makes Gem Day not trigger Turbo Hogrider (Gem Day stops counting as a Choose One card for Hogrider).
Run: python3 -I -B q7_paper.py"""
import importlib.util, os
from pathlib import Path
M = Path(__file__).resolve().parent.parent / 'model-copy'
spec = importlib.util.spec_from_file_location('p', M / 'presets3.py')
p = importlib.util.module_from_spec(spec); spec.loader.exec_module(p)
q = p.q
P = {k: {**v, 'cycle_cost': 6.0} for k, v in p.P.items()}
def run(line, kw, **x): return q.run(line, q.Dials(**{**kw, **x}))
for nm in ('B', 'C', 'uncut'):
    print(f'== preset {nm} (cycle cost 6): board R9 / R12 / R15, and strong/low at R12')
    for tag, x in (('as built', {}), ('coupling cut: Gem Day not a Choose One for Hogrider', dict(gemday_no_hog=True)),
                   ('axis cut: half Refiner steps', dict(refiner=(0.5, 0.5))),
                   ('both cuts', dict(gemday_no_hog=True, refiner=(0.5, 0.5)))):
        o = {ln: run(ln, P[nm], **x) for ln in ('typical', 'strong', 'low_roll')}
        t = o['typical']; s = o['strong']; l = o['low_roll']
        g = (t[14]['board'] / t[8]['board']) ** (1 / 6)
        print(f"  {tag:52s} typical {t[9]['board']:>6,} / {t[12]['board']:>6,} / {t[15]['board']:>7,}   strong {s[12]['board']:>6,} / {s[15]['board']:>7,}   low {l[12]['board']:>5,} / {l[15]['board']:>6,}   strong/low R12 {s[12]['board']/l[12]['board']:.1f}x   R8-14 x{g:.2f}   gem size R12 {t[12]['S']}")
