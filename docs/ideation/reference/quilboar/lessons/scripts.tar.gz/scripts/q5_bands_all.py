"""Quilboar win rate against all opponents by round band, and native-only baseline. Run: python3 -I q5_bands_all.py"""
import os, pickle
SCR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
fights, _ = pickle.load(open(os.path.join(SCR, "fights.pkl"), "rb"))
Q = "line_quilboar_engine"
def score(f, side):
    w = f["winner"]; return 1.0 if w == side else (0.0 if w in (0, 1) else 0.5)
for k in ("B_post", "C_pre", "uncut_post", "frozen_pre", "uncut_pre", "B_pre"):
    cells = []
    for lo, hi in ((6, 8), (9, 11), (12, 14), (15, 30)):
        s = [score(f, f["lines"].index(Q)) for f in fights[k] if lo <= f["round"] <= hi and Q in f["lines"]]
        b = [score(f, f["lines"].index("line_birds_homecoming")) for f in fights[k] if lo <= f["round"] <= hi and "line_birds_homecoming" in f["lines"] and Q not in f["lines"]]
        cells.append(f"R{lo}-{hi}: Q {sum(s)/len(s):.2f} (n={len(s)}), Birds vs natives {sum(b)/len(b):.2f}")
    print(k, " | ".join(cells))
