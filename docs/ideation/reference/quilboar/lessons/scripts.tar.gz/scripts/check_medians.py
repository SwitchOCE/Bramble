import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from load import *
for key in ARMS:
    L = load_arm(key)
    seeds = sorted(l['seed'] for l in L)
    row = []
    for rnd in (9, 12, 15):
        xs = [r['stats'] for l in L for r in l['rounds'] if r['line'] == 'line_quilboar_engine' and r['round'] == rnd]
        row.append((rnd, median(xs), len(xs)))
    print(key, len(L), seeds[0], seeds[-1], row)
