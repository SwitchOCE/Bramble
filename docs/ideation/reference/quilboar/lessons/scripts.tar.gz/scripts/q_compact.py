"""Answers from the committed compact archives only (lobbies.json.gz). Run: python3 -I q_compact.py > out_compact.txt"""
import math
import os
import random
import sys
from collections import Counter, defaultdict

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from load import ARMS, CANON, LINES, LINE_TRIBE, SHORT, fmt, load_arm, median, pct, seat_rounds, units  # noqa: E402

U = units()
DATA = {k: load_arm(k) for k in ARMS}
Q = "line_quilboar_engine"


def seats_of(lobby, line):
    return [p["seat"] for p in lobby["players"] if p["line"] == line]


def player(lobby, seat):
    return next(p for p in lobby["players"] if p["seat"] == seat)


def boot(lobbies, stat_fn, reps=2000, seed=481516):
    rng = random.Random(seed)
    vals = []
    n = len(lobbies)
    for _ in range(reps):
        sample = [lobbies[rng.randrange(n)] for _ in range(n)]
        v = stat_fn(sample)
        if v is not None:
            vals.append(v)
    vals.sort()
    return pct(vals, 0.025), pct(vals, 0.975)


def line_round_stats(lobbies, line, rnd, field="stats"):
    return [r[field] for l in lobbies for r in l["rounds"] if r["line"] == line and r["round"] == rnd]


def h(title):
    print()
    print("=" * 100)
    print(title)
    print("=" * 100)


# ---------------------------------------------------------------------------------------------
h("Q8. Third axis: uncut_pre vs frozen_pre (same seeds 2911001-2911100); B_pre vs C_pre (same seeds 2911001-2911150)")
for a, b in (("uncut_pre", "frozen_pre"), ("C_pre", "B_pre")):
    print(f"\n{a} vs {b}: Quilboar pre-start median (n survivors), ratio")
    for rnd in range(6, 17):
        xa = line_round_stats(DATA[a], Q, rnd)
        xb = line_round_stats(DATA[b], Q, rnd)
        ma, mb = median(xa), median(xb)
        print(f"  R{rnd:2d}  {a} {fmt(ma)} (n={len(xa)})   {b} {fmt(mb)} (n={len(xb)})   ratio {ma / mb if ma and mb else float('nan'):.2f}")
    for rnd in (12, 15):
        def ratio(sample, rnd=rnd):
            # paired bootstrap over seed: resample seeds, recompute both medians
            return None
        # Paired seed bootstrap
        sa = {l["seed"]: l for l in DATA[a]}
        sb = {l["seed"]: l for l in DATA[b]}
        common = sorted(set(sa) & set(sb))
        rng = random.Random(7)
        vals = []
        for _ in range(2000):
            pick = [common[rng.randrange(len(common))] for _ in common]
            xa = [r["stats"] for s in pick for r in sa[s]["rounds"] if r["line"] == Q and r["round"] == rnd]
            xb = [r["stats"] for s in pick for r in sb[s]["rounds"] if r["line"] == Q and r["round"] == rnd]
            if xa and xb:
                vals.append(median(xa) / median(xb))
        vals.sort()
        print(f"  R{rnd} ratio {a}/{b} paired-seed bootstrap 95%: [{pct(vals, .025):.2f}, {pct(vals, .975):.2f}]")
        # per-seed paired ratios where Quilboar alive in both
        pr = []
        for s in common:
            ra = [r["stats"] for r in sa[s]["rounds"] if r["line"] == Q and r["round"] == rnd]
            rb = [r["stats"] for r in sb[s]["rounds"] if r["line"] == Q and r["round"] == rnd]
            if ra and rb and rb[0] > 0:
                pr.append(ra[0] / rb[0])
        if pr:
            print(f"  R{rnd} per-seed ratio (both alive, n={len(pr)}): median {median(pr):.2f}, share where {a} larger {sum(1 for x in pr if x > 1) / len(pr):.2f}")

print("\nSurvival, placement and gem size by arm (Quilboar seat)")
for k in ARMS:
    L = DATA[k]
    places = [player(l, s)["place"] for l in L for s in seats_of(l, Q)]
    alive12 = sum(1 for l in L for r in l["rounds"] if r["line"] == Q and r["round"] == 12) / len(L)
    alive15 = sum(1 for l in L for r in l["rounds"] if r["line"] == Q and r["round"] == 15) / len(L)
    gs = {}
    for rnd in (6, 9, 12, 15):
        g = [r["gem_size"] for l in L for r in l["rounds"] if r["line"] == Q and r["round"] == rnd]
        gs[rnd] = (median([x[0] for x in g]) / 2 if g else None, median([x[1] for x in g]) / 2 if g else None)
    print(f"  {k:11s} mean place {sum(places) / len(places):.2f}  first {sum(1 for p in places if p == 1) / len(places):.2f}  top4 {sum(1 for p in places if p <= 4) / len(places):.2f}  alive R12 {alive12:.2f} R15 {alive15:.2f}  gem size (A/H, halves/2) "
          + "  ".join(f"R{r} {gs[r][0]}/{gs[r][1]}" for r in gs))

print("\nNative lines' outcomes when the Quilboar seat is uncut vs frozen (same seeds), and B vs C")
for a, b in (("uncut_pre", "frozen_pre"), ("C_pre", "B_pre")):
    print(f"  {a} -> {b}")
    for line in LINES:
        pa = [player(l, s)["place"] for l in DATA[a] for s in seats_of(l, line)]
        pb = [player(l, s)["place"] for l in DATA[b] for s in seats_of(l, line)]
        fa = sum(1 for p in pa if p == 1) / len(pa)
        fb = sum(1 for p in pb if p == 1) / len(pb)
        m12a = median(line_round_stats(DATA[a], line, 12))
        m12b = median(line_round_stats(DATA[b], line, 12))
        m15a = median(line_round_stats(DATA[a], line, 15))
        m15b = median(line_round_stats(DATA[b], line, 15))
        print(f"    {SHORT[line]:9s} mean place {sum(pa) / len(pa):.2f} -> {sum(pb) / len(pb):.2f}   first {fa:.2f} -> {fb:.2f}   R12 {fmt(m12a)} -> {fmt(m12b)}   R15 {fmt(m15a)} -> {fmt(m15b)}")

print("\nShare of the uncut_pre R12 log-gap to each native line that freezing size removes: ln(uncut/frozen) / ln(uncut/native)")
mu = median(line_round_stats(DATA["uncut_pre"], Q, 12))
mf = median(line_round_stats(DATA["frozen_pre"], Q, 12))
for line in LINES[1:]:
    mn = median(line_round_stats(DATA["uncut_pre"], line, 12))
    print(f"  {SHORT[line]:9s} native R12 {fmt(mn)}  uncut/native {mu / mn:.2f}x  size share of log gap {math.log(mu / mf) / math.log(mu / mn):.2f}")

# ---------------------------------------------------------------------------------------------
h("Q5. Timing: lobby end round, Quilboar elimination round, same-cohort growth R12->R15")
for k in CANON + ["B_pre", "uncut_pre"]:
    L = DATA[k]
    ends = [max(p["rounds"] for p in l["players"]) for l in L]
    qrounds = [player(l, s)["rounds"] for l in L for s in seats_of(l, Q)]
    qwin = [player(l, s)["rounds"] for l in L for s in seats_of(l, Q) if player(l, s)["place"] == 1]
    qlose = [player(l, s)["rounds"] for l in L for s in seats_of(l, Q) if player(l, s)["place"] > 1]
    # round when the lobby is down to 4 or fewer players
    top4_round = []
    for l in L:
        rs = sorted(p["rounds"] for p in l["players"])
        top4_round.append(rs[3] + 1)  # 4th elimination happens after rs[3] rounds -> 4 left from next round
    winners = Counter(player(l, s)["line"] for l in L for s in [p["seat"] for p in l["players"] if p["place"] == 1])
    print(f"  {k:11s} lobby end round median {median(ends)} [p10 {pct(ends, .1):.0f}, p90 {pct(ends, .9):.0f}]  share ended by R14 {sum(1 for e in ends if e <= 14) / len(ends):.2f}, by R16 {sum(1 for e in ends if e <= 16) / len(ends):.2f}"
          f"  | 4 left from round {median(top4_round)}  | Quilboar last round: median {median(qrounds)}; when not 1st {median(qlose)}")
    print("      winners by line: " + ", ".join(f"{SHORT[ln]} {c}" for ln, c in winners.most_common()))

print("\nSame-cohort growth (seats alive at R15): median of per-seat (R15/R12)^(1/3), and median R12 and R15 of that cohort")
for k in CANON:
    L = DATA[k]
    print(f"  {k}")
    for line in LINES:
        g = []
        a12 = []
        a15 = []
        for l in L:
            sr = seat_rounds(l)
            for s in seats_of(l, line):
                if 12 in sr[s] and 15 in sr[s] and sr[s][12]["stats"] > 0:
                    g.append((sr[s][15]["stats"] / sr[s][12]["stats"]) ** (1 / 3))
                    a12.append(sr[s][12]["stats"])
                    a15.append(sr[s][15]["stats"])
        if g:
            print(f"    {SHORT[line]:9s} n={len(g):3d}  growth/round {median(g):.2f}  cohort R12 {fmt(median(a12))}  R15 {fmt(median(a15))}")

print("\nQuilboar / line median ratio by round (survivor medians), canonical arms")
for k in CANON:
    L = DATA[k]
    print(f"  {k}: " + "  ".join(
        f"R{r}: " + ",".join(f"{SHORT[ln][:3]} {median(line_round_stats(L, Q, r)) / median(line_round_stats(L, ln, r)):.1f}" for ln in LINES[1:3])
        for r in (9, 12, 13, 15)))

# ---------------------------------------------------------------------------------------------
h("Q3. Power jumps: largest one-round pre-start growth per seat (R7-R16, previous board >= 30)")
for k in CANON:
    L = DATA[k]
    print(f"  {k}")
    for line in LINES:
        jumps = []
        rounds_of = []
        big2 = 0
        n = 0
        place_with, place_without = [], []
        for l in L:
            sr = seat_rounds(l)
            for s in seats_of(l, line):
                best = (0, None)
                for r in range(7, 17):
                    if r in sr[s] and r - 1 in sr[s] and sr[s][r - 1]["stats"] >= 30:
                        ratio = sr[s][r]["stats"] / sr[s][r - 1]["stats"]
                        if ratio > best[0]:
                            best = (ratio, r)
                if best[1] is None:
                    continue
                n += 1
                jumps.append(best[0])
                rounds_of.append(best[1])
                pl = player(l, s)["place"]
                if best[0] >= 2:
                    big2 += 1
                    place_with.append(pl)
                else:
                    place_without.append(pl)
        mw = sum(place_with) / len(place_with) if place_with else None
        mo = sum(place_without) / len(place_without) if place_without else None
        print(f"    {SHORT[line]:9s} n={n:3d} median largest jump x{median(jumps):.2f} (p90 x{pct(jumps, .9):.2f}) at round {median(rounds_of)}; share with a >=x2 round {big2 / n:.2f}; mean place with x2 {fmt(mw, 2)} / without {fmt(mo, 2)}")

# ---------------------------------------------------------------------------------------------
h("Q9. Keystone dependence: Hogrider by R12 (keystone_found_round) and native engine pieces by R12")
for k in ARMS:
    L = DATA[k]
    rows = []
    for l in L:
        sr = seat_rounds(l)
        for s in seats_of(l, Q):
            kr = None
            for r in sorted(sr[s]):
                if sr[s][r]["keystone_found_round"] is not None:
                    kr = sr[s][r]["keystone_found_round"]
                    break
            rows.append((kr, player(l, s)["place"], sr[s].get(12, {}).get("stats"), sr[s].get(15, {}).get("stats")))
    got = [x for x in rows if x[0] is not None and x[0] <= 12]
    miss = [x for x in rows if not (x[0] is not None and x[0] <= 12)]
    print(f"  {k:11s} Hogrider by R12 {len(got) / len(rows):.2f}; mean place with {sum(x[1] for x in got) / len(got):.2f}, without {sum(x[1] for x in miss) / len(miss):.2f}; first-place with {sum(1 for x in got if x[1] == 1) / len(got):.2f}, without {sum(1 for x in miss if x[1] == 1) / len(miss):.2f}"
          f"; R12 median with {fmt(median([x[2] for x in got if x[2] is not None]))} without {fmt(median([x[2] for x in miss if x[2] is not None]))}")
    byr = defaultdict(list)
    for x in rows:
        b = "never" if x[0] is None else ("<=10" if x[0] <= 10 else (str(x[0]) if x[0] <= 14 else ">=15"))
        byr[b].append(x)
    order = ["<=10", "11", "12", "13", "14", ">=15", "never"]
    print("      by Hogrider round: " + "; ".join(
        f"{b}: n={len(byr[b])} place {sum(x[1] for x in byr[b]) / len(byr[b]):.2f} first {sum(1 for x in byr[b] if x[1] == 1) / len(byr[b]):.2f}" for b in order if byr[b]))

print("\nSpread at R12 (p90/p10 and p90/median of survivor boards) by line, canonical arms; paper strong/low for Quilboar B is 5.5x")
for k in CANON:
    L = DATA[k]
    print(f"  {k}: " + "; ".join(
        f"{SHORT[ln]} p90/p10 {pct(line_round_stats(L, ln, 12), .9) / pct(line_round_stats(L, ln, 12), .1):.1f} p90/med {pct(line_round_stats(L, ln, 12), .9) / median(line_round_stats(L, ln, 12)):.1f}"
        for ln in LINES))

# native engine pieces (legacy profiles in tools/sim/line_profiles.committed.json at bb8bb5f2)
ENGINE = {
    "line_bog_engine": ["jenny_greenteeth", "vaulting_hopkin", "peat_king"],
    "line_hedgerow_engine": ["alderman_dozey", "honorary_treasurer", "squire_lollop"],
    "line_hunters_engine": ["brother_wolf", "grizel"],
    "line_oozes_engine": ["mr_syllabub", "elder_ooze"],
}
print("\nNative legacy lines: any listed engine piece on the pre-start board by R12 (bb8bb5f2 line_profiles.committed.json engine_pieces)")
for k in CANON:
    L = DATA[k]
    for line, pieces in ENGINE.items():
        got, miss = [], []
        for l in L:
            sr = seat_rounds(l)
            for s in seats_of(l, line):
                found = any(u["id"] in pieces for r in range(1, 13) if r in sr[s] for u in sr[s][r]["units"])
                (got if found else miss).append(player(l, s)["place"])
        tot = len(got) + len(miss)
        print(f"  {k:11s} {SHORT[line]:9s} engine piece by R12 {len(got) / tot:.2f}; mean place with {fmt(sum(got) / len(got) if got else None, 2)} without {fmt(sum(miss) / len(miss) if miss else None, 2)}")

# ---------------------------------------------------------------------------------------------
h("Q2. Commit and engine arrival rounds for the Quilboar seat")
for k in CANON:
    L = DATA[k]
    commits = Counter()
    first = defaultdict(list)
    for l in L:
        sr = seat_rounds(l)
        for s in seats_of(l, Q):
            cr = next((sr[s][r]["commit_round"] for r in sorted(sr[s]) if sr[s][r]["commit_round"] is not None), None)
            commits[cr] += 1
            for piece in ("qb_gem_rat", "qb_bramble_tunneler", "qb_sanguine_refiner", "qb_turbo_hogrider"):
                fr = next((r for r in sorted(sr[s]) if any(u["id"] == piece for u in sr[s][r]["units"])), None)
                first[piece].append(fr)
    print(f"  {k:11s} commit rounds {dict(sorted(commits.items(), key=lambda x: (x[0] is None, x[0])))}")
    for piece, xs in first.items():
        have = [x for x in xs if x is not None]
        print(f"      {piece:22s} ever on board {len(have) / len(xs):.2f}; median first round {median(have)}; by R8 {sum(1 for x in have if x <= 8) / len(xs):.2f}")
    # placement by first engine piece (Rat or Tunneler) round
    byr = defaultdict(list)
    for l in L:
        sr = seat_rounds(l)
        for s in seats_of(l, Q):
            fr = next((r for r in sorted(sr[s]) if any(u["id"] in ("qb_gem_rat", "qb_bramble_tunneler") for u in sr[s][r]["units"])), None)
            byr["never" if fr is None else ("<=6" if fr <= 6 else ("7-8" if fr <= 8 else ">=9"))].append(player(l, s)["place"])
    print("      place by first Rat/Tunneler round: " + "; ".join(f"{b}: n={len(v)} place {sum(v) / len(v):.2f}" for b, v in byr.items()))

print("\nHard seat: chosen line (current_line at R1 and last round), and whether it ever changes")
for k in CANON:
    L = DATA[k]
    changes = 0
    n = 0
    finals = Counter()
    for l in L:
        sr = seat_rounds(l)
        for s in seats_of(l, "hard"):
            n += 1
            lines = [sr[s][r]["current_line"] for r in sorted(sr[s])]
            if len(set(lines)) > 1:
                changes += 1
            finals[player(l, s)["final_tribe"] or "none"] += 1
    print(f"  {k:11s} Hard seats {n}, line changed during game {changes}; final tribe {dict(finals.most_common())}")

# ---------------------------------------------------------------------------------------------
h("Q1. Early flex: own-tribe share of the board, units on board, and off-tribe use of native T1-T3 cards")


def tribe_of(uid):
    t = U.get(uid, {}).get("tribes") or ["(neutral)"]
    return t[0]


for k in CANON:
    L = DATA[k]
    print(f"  {k}")
    for line in LINES:
        cells = []
        for rnd in (2, 3, 4, 5, 6, 7, 8, 10):
            own = tot = 0
            counts = []
            for l in L:
                sr = seat_rounds(l)
                for s in seats_of(l, line):
                    if rnd not in sr[s]:
                        continue
                    us = [u for u in sr[s][rnd]["units"] if u.get("active", True)]
                    counts.append(len(us))
                    want = LINE_TRIBE.get(line) or (player(l, s)["final_tribe"] or "")
                    for u in us:
                        tot += 1
                        own += tribe_of(u["id"]) == want
            cells.append(f"R{rnd} {own / tot if tot else 0:.2f}/{median(counts) if counts else 0}")
        print(f"    {SHORT[line]:9s} own-tribe unit share / median units: " + "  ".join(cells))

print("\nQuilboar seat's off-tribe units on board R2-R7 (which of our cards the flexing seat keeps), canonical arms pooled")
c = Counter()
seatn = 0
for k in CANON:
    for l in DATA[k]:
        sr = seat_rounds(l)
        for s in seats_of(l, Q):
            seatn += 1
            held = set()
            for r in range(2, 8):
                if r in sr[s]:
                    for u in sr[s][r]["units"]:
                        if not u["id"].startswith("qb_"):
                            held.add(u["id"])
            for uid in held:
                c[uid] += 1
print(f"  seats {seatn}; top cards (share of Quilboar seats that held it at some point R2-R7):")
for uid, n in c.most_common(20):
    print(f"    {uid:22s} {tribe_of(uid):14s} T{U.get(uid, {}).get('tier')}  {n / seatn:.2f}")
tribe_c = Counter()
for uid, n in c.items():
    tribe_c[tribe_of(uid)] += n
print("  by tribe (seat-card holdings): " + ", ".join(f"{t} {n}" for t, n in tribe_c.most_common()))

print("\nOff-tribe uptake of each tribe's T1-T2 cards: share of seat-games whose final tribe is another tribe that held the card on board at some round R1-R8 (canonical arms pooled)")
uptake = defaultdict(lambda: [0, 0])  # uid -> [held, denominators]
denom_by_tribe = Counter()
for k in CANON:
    for l in DATA[k]:
        sr = seat_rounds(l)
        for p in l["players"]:
            s = p["seat"]
            ft = p["final_tribe"] or ""
            held = set()
            for r in range(1, 9):
                if r in sr.get(s, {}):
                    for u in sr[s][r]["units"]:
                        held.add(u["id"])
            for t in ("Birds", "Fairies", "Bog folk", "Hedgerow folk", "Hunters", "Oozes"):
                if ft != t:
                    denom_by_tribe[t] += 1
            for uid in held:
                t = tribe_of(uid)
                if t != ft and U.get(uid, {}).get("tier") in (1, 2):
                    uptake[uid][0] += 1
for t in ("Birds", "Fairies", "Bog folk", "Hedgerow folk", "Hunters", "Oozes"):
    cards = sorted((uid for uid in U if tribe_of(uid) == t and U[uid]["tier"] in (1, 2) and U[uid]["pool"]), key=lambda x: -uptake[x][0])
    best = [(uid, uptake[uid][0] / denom_by_tribe[t]) for uid in cards]
    print(f"  {t:14s} denominators {denom_by_tribe[t]}: " + ", ".join(f"{uid} T{U[uid]['tier']} {v:.3f}" for uid, v in best[:5]))

print("\nWho holds those off-tribe early cards (by seat line), canonical arms pooled")
by_holder = Counter()
for k in CANON:
    for l in DATA[k]:
        sr = seat_rounds(l)
        for p in l["players"]:
            s = p["seat"]
            ft = p["final_tribe"] or ""
            held = set()
            for r in range(1, 9):
                if r in sr.get(s, {}):
                    for u in sr[s][r]["units"]:
                        if tribe_of(u["id"]) not in (ft, "(neutral)") and U.get(u["id"], {}).get("tier") in (1, 2, 3):
                            held.add(u["id"])
            by_holder[SHORT[p["line"]]] += len(held)
print("  off-tribe T1-T3 native card holdings by holder line: " + ", ".join(f"{k} {v}" for k, v in by_holder.most_common()))

# ---------------------------------------------------------------------------------------------
h("Q4 (compact part). Biggest-unit share by line, R12 and R15 (median over survivors)")
for k in CANON:
    L = DATA[k]
    print(f"  {k}: " + "; ".join(
        f"{SHORT[ln]} {median(line_round_stats(L, ln, 12, 'largest_share')):.2f}/{fmt(median(line_round_stats(L, ln, 15, 'largest_share')), 2)}" for ln in LINES))

# ---------------------------------------------------------------------------------------------
h("Q10 (compact part). Native cards on Quilboar boards from R8 (splash candidates), canonical arms pooled")
c = Counter()
n = 0
for k in CANON:
    for l in DATA[k]:
        sr = seat_rounds(l)
        for s in seats_of(l, Q):
            n += 1
            held = set()
            for r in range(8, 25):
                if r in sr[s]:
                    for u in sr[s][r]["units"]:
                        if not u["id"].startswith("qb_"):
                            held.add(u["id"])
            for uid in held:
                c[uid] += 1
print(f"  Quilboar seats {n}; share holding any native unit from R8: {sum(1 for _ in [0]) and ''}")
print("  " + ", ".join(f"{uid} {v / n:.2f}" for uid, v in c.most_common(12)))
