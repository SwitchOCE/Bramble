"""Q4 robustness: Quilboar win rate at equal pre-start totals, split by round band. Run: python3 -I q4_bands.py"""
import os, pickle, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
SCR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
fights, _ = pickle.load(open(os.path.join(SCR, "fights.pkl"), "rb"))
Q = "line_quilboar_engine"
def score(f, side):
    w = f["winner"]; return 1.0 if w == side else (0.0 if w in (0, 1) else 0.5)
for k in ("B_post", "C_pre", "uncut_post", "frozen_pre"):
    cells = []
    for lo, hi in ((6, 8), (9, 11), (12, 14), (15, 30)):
        s = []; nn = []
        for f in fights[k]:
            if not (lo <= f["round"] <= hi): continue
            if Q in f["lines"]:
                i = f["lines"].index(Q); a, b = f["stats"][i], f["stats"][1 - i]
                if b > 0 and 0.8 <= a / b <= 1.25: s.append(score(f, i))
        cells.append(f"R{lo}-{hi}: {sum(s)/len(s):.2f} (n={len(s)})" if s else f"R{lo}-{hi}: -")
    print(k, "  ".join(cells))
