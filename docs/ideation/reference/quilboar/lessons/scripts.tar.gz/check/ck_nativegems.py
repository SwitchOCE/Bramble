"""Do non-Quilboar seats hold qb_ units, and does their gem size ever move? Run: python3 -I ck_nativegems.py"""
import glob, gzip, json
from collections import Counter
EV = "/home/alex/code/Bramble-ideation-sol/tools/sim/evidence"
ARMS = {"B_post": EV + "/quilboar-h1-cycle-fix/B", "C_pre": EV + "/quilboar-h1/C",
        "uncut_post": EV + "/quilboar-h1-cycle-fix/uncut", "frozen_pre": EV + "/quilboar-h1/uncut_frozen"}
ids = Counter(); gs = Counter(); seatgames = set(); nonq_seatgames = 0
for k, v in ARMS.items():
    for f in sorted(glob.glob(v + "/*.lobbies.json.gz")):
        for l in json.load(gzip.open(f, "rt")):
            for r in l["rounds"]:
                if r["line"] == "line_quilboar_engine":
                    continue
                q = [u["id"] for u in r["units"] if u["id"].startswith("qb_")]
                for i in q:
                    ids[(r["line"] if r["line"] == "hard" else "native", i)] += 1
                if q:
                    seatgames.add((k, l["seed"], r["seat"], r["line"] == "hard"))
                gs[tuple(r.get("gem_size") or [])] += 1
print("non-Quilboar seat-rounds by qb_ id:", ids.most_common(20))
print("non-Quilboar seat-games holding any qb_ unit: hard", sum(1 for s in seatgames if s[3]), "native", sum(1 for s in seatgames if not s[3]))
print("non-Quilboar gem_size values (halves):", gs.most_common(8))

# seat-games where a non-Quilboar seat's gem size left 2/2, by line
moved = set(); tot = set()
for k, v in ARMS.items():
    for f in sorted(glob.glob(v + "/*.lobbies.json.gz")):
        for l in json.load(gzip.open(f, "rt")):
            for r in l["rounds"]:
                if r["line"] == "line_quilboar_engine":
                    continue
                tot.add((k, l["seed"], r["seat"], r["line"]))
                if tuple(r.get("gem_size") or [2, 2]) != (2, 2):
                    moved.add((k, l["seed"], r["seat"], r["line"]))
print("non-Quilboar seat-games:", len(tot), " with gem size moved:", len(moved), Counter(x[3] for x in moved))
