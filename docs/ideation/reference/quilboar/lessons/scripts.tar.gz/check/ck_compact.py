"""Skeptic's independent recompute from the committed compact archives (read only).
Run: python3 -I ck_compact.py > ck_compact.txt
"""
import glob, gzip, json, math, random, statistics
from collections import Counter, defaultdict

EV = "/home/alex/code/Bramble-ideation-sol/tools/sim/evidence"
ARMS = {
    "B_pre": EV + "/quilboar-h1/B",
    "C_pre": EV + "/quilboar-h1/C",
    "uncut_pre": EV + "/quilboar-h1/uncut",
    "frozen_pre": EV + "/quilboar-h1/uncut_frozen",
    "B_post": EV + "/quilboar-h1-cycle-fix/B",
    "uncut_post": EV + "/quilboar-h1-cycle-fix/uncut",
}
CANON = ["B_post", "C_pre", "uncut_post", "frozen_pre"]
Q = "line_quilboar_engine"
LINES = [Q, "line_birds_homecoming", "line_fairies_ring", "line_bog_engine", "line_hedgerow_engine",
         "line_hunters_engine", "line_oozes_engine", "hard"]
S = dict(zip(LINES, ["Quil", "Birds", "Fairies", "Bog", "Hedge", "Hunters", "Oozes", "Hard"]))


def load(folder):
    out = []
    for f in sorted(glob.glob(folder + "/*.lobbies.json.gz")):
        with gzip.open(f, "rt") as fh:
            out.extend(json.load(fh))
    return out


D = {k: load(v) for k, v in ARMS.items()}
med = statistics.median


def q(xs, p):
    xs = sorted(xs)
    k = (len(xs) - 1) * p
    lo = math.floor(k); hi = min(lo + 1, len(xs) - 1)
    return xs[lo] + (xs[hi] - xs[lo]) * (k - lo)


def board(L, line, rnd):
    return [r["stats"] for l in L for r in l["rounds"] if r["line"] == line and r["round"] == rnd]


def players(L, line):
    return [p for l in L for p in l["players"] if p["line"] == line]


print("n lobbies:", {k: len(v) for k, v in D.items()})
print("seeds:", {k: (min(l['seed'] for l in v), max(l['seed'] for l in v)) for k, v in D.items()})
print("seats per line per lobby:", {k: Counter(p['line'] for l in v[:1] for p in l['players']) for k, v in D.items()})

print("\n=== F1: uncut_pre vs frozen_pre Quilboar medians")
for rnd in range(9, 17):
    a = board(D["uncut_pre"], Q, rnd); b = board(D["frozen_pre"], Q, rnd)
    print(f"R{rnd} uncut_pre {med(a)} n={len(a)}  frozen {med(b)} n={len(b)}  ratio {med(a)/med(b):.2f}")
# paired seed bootstrap
for (A, B) in (("uncut_pre", "frozen_pre"), ("C_pre", "B_pre")):
    sa = {l["seed"]: l for l in D[A]}; sb = {l["seed"]: l for l in D[B]}
    com = sorted(set(sa) & set(sb))
    for rnd in (12, 15):
        rng = random.Random(1)
        vals = []
        for _ in range(4000):
            pick = [com[rng.randrange(len(com))] for _ in com]
            xa = [r["stats"] for s in pick for r in sa[s]["rounds"] if r["line"] == Q and r["round"] == rnd]
            xb = [r["stats"] for s in pick for r in sb[s]["rounds"] if r["line"] == Q and r["round"] == rnd]
            vals.append(med(xa) / med(xb))
        pr = []
        for s in com:
            ra = [r["stats"] for r in sa[s]["rounds"] if r["line"] == Q and r["round"] == rnd]
            rb = [r["stats"] for r in sb[s]["rounds"] if r["line"] == Q and r["round"] == rnd]
            if ra and rb:
                pr.append(ra[0] / rb[0])
        pt = med(board(D[A], Q, rnd)) / med(board(D[B], Q, rnd))
        print(f"{A}/{B} R{rnd}: point {pt:.3f} boot95 [{q(vals,.025):.2f},{q(vals,.975):.2f}]  per-seed both alive n={len(pr)} share A>B {sum(x>1 for x in pr)/len(pr):.2f} median {med(pr):.2f}")

print("\n=== F2: log-gap share at R12, natives from uncut_pre and from frozen_pre lobbies")
mu = med(board(D["uncut_pre"], Q, 12)); mf = med(board(D["frozen_pre"], Q, 12))
for line in LINES[1:]:
    for src in ("uncut_pre", "frozen_pre", "uncut_post"):
        mn = med(board(D[src], line, 12))
        print(f"  {S[line]:8s} natives from {src:10s} R12 {mn}  share {math.log(mu/mf)/math.log(mu/mn):.2f}  frozen/native {mf/mn:.2f}")

print("\n=== F3: Quilboar outcomes by arm")
for k in D:
    P = players(D[k], Q)
    n = len(P)
    pl = [p["place"] for p in P]
    alive15 = len(board(D[k], Q, 15)) / n
    alive12 = len(board(D[k], Q, 12)) / n
    alive15b = sum(p["rounds"] >= 15 for p in P) / n
    print(f"  {k:10s} n={n} mean place {sum(pl)/n:.2f} first {sum(x==1 for x in pl)/n:.2f} top4 {sum(x<=4 for x in pl)/n:.2f} aliveR12 {alive12:.2f} aliveR15(rows) {alive15:.2f} (players.rounds>=15 {alive15b:.2f})")
print("  other lines' first-place and mean place by arm")
for k in D:
    cells = []
    for line in LINES[1:]:
        P = players(D[k], line)
        cells.append(f"{S[line]} {sum(p['place'] for p in P)/len(P):.2f}/{sum(p['place']==1 for p in P)/len(P):.2f}")
    print(f"  {k:10s} " + "  ".join(cells))

print("\n=== F4: C vs B (pre) medians")
for rnd in (9, 12, 15):
    c = med(board(D["C_pre"], Q, rnd)); b = med(board(D["B_pre"], Q, rnd)); bp = med(board(D["B_post"], Q, rnd))
    print(f"  R{rnd} C {c} B_pre {b} B_post {bp}  C/B_pre {c/b:.3f}  C/B_post {c/bp:.3f}")

print("\n=== F5: p90/p10 at R12 by line and arm (survivors), and p90/p50, p50/p10")
for k in CANON + ["B_pre", "uncut_pre"]:
    cells = []
    for line in LINES:
        x = board(D[k], line, 12)
        cells.append(f"{S[line]} {q(x,.9)/q(x,.1):.1f}")
    print(f"  {k:10s} " + "  ".join(cells))

print("\n=== F8: same-cohort growth R12->R15 (per-seat geometric), and alive counts")
for k in CANON:
    cells = []
    for line in LINES:
        g = []
        for l in D[k]:
            by = defaultdict(dict)
            for r in l["rounds"]:
                by[r["seat"]][r["round"]] = r
            for p in l["players"]:
                if p["line"] != line:
                    continue
                s = by[p["seat"]]
                if 12 in s and 15 in s and s[12]["stats"] > 0:
                    g.append((s[15]["stats"] / s[12]["stats"]) ** (1 / 3))
        cells.append(f"{S[line]} x{med(g):.2f} (n={len(g)})")
    print(f"  {k:10s} " + "  ".join(cells))
# same-cohort R8->R12 growth (to see if natives flatten specifically after R12)
print("  same-cohort R8->R12 per round (seats alive at R12)")
for k in CANON:
    cells = []
    for line in LINES:
        g = []
        for l in D[k]:
            by = defaultdict(dict)
            for r in l["rounds"]:
                by[r["seat"]][r["round"]] = r
            for p in l["players"]:
                if p["line"] != line:
                    continue
                s = by[p["seat"]]
                if 8 in s and 12 in s and s[8]["stats"] > 0:
                    g.append((s[12]["stats"] / s[8]["stats"]) ** (1 / 4))
        cells.append(f"{S[line]} x{med(g):.2f}")
    print(f"  {k:10s} " + "  ".join(cells))

print("\n=== F9: lobby end, 4-left round, Quilboar elimination")
for k in CANON + ["B_pre", "uncut_pre"]:
    L = D[k]
    ends = [max(p["rounds"] for p in l["players"]) for l in L]
    four = []
    for l in L:
        rs = sorted(p["rounds"] for p in l["players"])  # 8 seats
        # players alive at round r: count rounds>=r. 4 left = first round r where count(rounds>=r) <= 4
        r = 1
        while sum(x >= r for x in rs) > 4:
            r += 1
        four.append(r)
    P = players(L, Q)
    lose = [p["rounds"] for p in P if p["place"] > 1]
    print(f"  {k:10s} end median {med(ends)} p10 {q(ends,.1)} min {min(ends)} ended<=14 {sum(e<=14 for e in ends)}  first round with <=4 alive median {med(four)}  Quil non-winner last round median {med(lose)}")
# hero HP at R12 for Quilboar winners vs non-winners (B_post)
for k in ("B_post",):
    win, non = [], []
    for l in D[k]:
        pl = {p["seat"]: p for p in l["players"]}
        for r in l["rounds"]:
            if r["line"] == Q and r["round"] == 12:
                (win if pl[r["seat"]]["place"] == 1 else non).append(r["health"])
    print(f"  {k} Quil hero HP at R12: winners {med(win)} n={len(win)}, non-winners {med(non)} n={len(non)}")

print("\n=== F10: x2 round share (largest one-round ratio R7-R16, prev >= 30)")
for k in CANON:
    cells = []
    for line in LINES:
        has = []
        for l in D[k]:
            by = defaultdict(dict)
            for r in l["rounds"]:
                by[r["seat"]][r["round"]] = r["stats"]
            for p in l["players"]:
                if p["line"] != line:
                    continue
                s = by[p["seat"]]
                best = 0
                for rr in range(7, 17):
                    if rr in s and rr - 1 in s and s[rr - 1] >= 30:
                        best = max(best, s[rr] / s[rr - 1])
                has.append(best >= 2)
        cells.append(f"{S[line]} {sum(has)/len(has):.2f}")
    print(f"  {k:10s} " + "  ".join(cells))

print("\n=== F12: commit round, Hard current_line changes")
for k in CANON:
    P = [(l, p) for l in D[k] for p in l["players"] if p["line"] == Q]
    cr = Counter()
    for l in D[k]:
        for r in l["rounds"]:
            if r["line"] == Q:
                cr[(l["seed"], r["seat"])] = r.get("commit_round")
    c = Counter(cr.values())
    print(f"  {k} Quil commit_round dist {sorted(c.items(), key=lambda x: (x[0] is None, x[0] or 0))}")
hard_lines = Counter(); changed = 0; nh = 0
for k in CANON:
    for l in D[k]:
        by = defaultdict(set)
        first = {}
        for r in l["rounds"]:
            if r["line"] == "hard":
                by[r["seat"]].add(r["current_line"])
                if r["seat"] not in first or r["round"] < first[r["seat"]][0]:
                    first[r["seat"]] = (r["round"], r["current_line"])
        for s, v in by.items():
            nh += 1
            changed += len(v) > 1
            hard_lines[first[s][1]] += 1
print(f"  Hard seats {nh}, changed line {changed}, distinct first lines {len(hard_lines)}: {hard_lines.most_common(5)}")
# also check native lines' current_line / final_line
nchg = 0; nn = 0
for k in CANON:
    for l in D[k]:
        for p in l["players"]:
            if p["line"] not in (Q, "hard"):
                nn += 1
                nchg += p["final_line"] != p["line"]
print(f"  native seats {nn}, final_line != line {nchg}")
# engine start round vs place
print("  engine start (first round Gem Rat or Tunneler on board) vs mean place")
for k in CANON:
    buckets = defaultdict(list)
    for l in D[k]:
        pl = {p["seat"]: p for p in l["players"]}
        first = {}
        for r in sorted(l["rounds"], key=lambda r: r["round"]):
            if r["line"] != Q:
                continue
            if r["seat"] not in first and any(u["id"] in ("qb_gem_rat", "qb_bramble_tunneler") for u in r["units"]):
                first[r["seat"]] = r["round"]
        for s, p in pl.items():
            if p["line"] != Q:
                continue
            f = first.get(s)
            b = "none" if f is None else ("<=6" if f <= 6 else ("7-8" if f <= 8 else "9+"))
            buckets[b].append(p["place"])
    print(f"  {k:10s} " + "  ".join(f"{b} {sum(v)/len(v):.2f} (n={len(v)})" for b, v in sorted(buckets.items())))
