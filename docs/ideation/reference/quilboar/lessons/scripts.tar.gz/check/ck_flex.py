"""Skeptic's Q1 recompute: own-tribe share by round and off-tribe uptake of T1-T2 cards.
Unit tribes/tiers: git archive of bb8bb5f2 into ./content-bb8bb5f2 (read only source).
Run: python3 -I ck_flex.py > ck_flex.txt
"""
import glob, gzip, json, os
from collections import Counter, defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
EV = "/home/alex/code/Bramble-ideation-sol/tools/sim/evidence"
ARMS = {"B_post": EV + "/quilboar-h1-cycle-fix/B", "C_pre": EV + "/quilboar-h1/C",
        "uncut_post": EV + "/quilboar-h1-cycle-fix/uncut", "frozen_pre": EV + "/quilboar-h1/uncut_frozen"}
U = {}
for f in glob.glob(HERE + "/content-bb8bb5f2/content/units/*.json") + glob.glob(HERE + "/content-bb8bb5f2/content/reference/quilboar/units/*.json"):
    u = json.load(open(f))
    tr = ["quilboar"] if u["id"].startswith("qb_") else (u.get("tribes") or [])
    U[u["id"]] = (u.get("tier"), tr, u.get("name"))
LT = {"line_quilboar_engine": "quilboar", "line_birds_homecoming": "Birds", "line_fairies_ring": "Fairies",
      "line_bog_engine": "Bog folk", "line_hedgerow_engine": "Hedgerow folk", "line_hunters_engine": "Hunters",
      "line_oozes_engine": "Oozes"}
D = {}
for k, v in ARMS.items():
    D[k] = []
    for f in sorted(glob.glob(v + "/*.lobbies.json.gz")):
        D[k].extend(json.load(gzip.open(f, "rt")))
missing = Counter()
print("=== own-tribe unit share on board (mean of per-board share), by line and round, B_post and pooled canonical")
for scope in (["B_post"], list(ARMS)):
    print(" scope", scope)
    for line, tribe in LT.items():
        cells = []
        for rnd in (2, 3, 4, 5, 6, 7, 8, 10):
            sh = []
            for k in scope:
                for l in D[k]:
                    for r in l["rounds"]:
                        if r["line"] != line or r["round"] != rnd:
                            continue
                        us = [u for u in r["units"] if u.get("active", True)]
                        if not us:
                            continue
                        n = 0
                        for u in us:
                            if u["id"] not in U:
                                missing[u["id"]] += 1
                                continue
                            n += tribe in U[u["id"]][1]
                        sh.append(n / len(us))
            cells.append(f"R{rnd} {sum(sh)/len(sh):.2f}" if sh else f"R{rnd} -")
        print(f"   {line:24s} " + " ".join(cells))
print("missing ids:", missing.most_common(5))

print("\n=== off-tribe uptake by R8: share of seat-games whose final_tribe differs from the card's tribe that had the card on board R1-R8")
held = defaultdict(int)
den = Counter()
by_holder = defaultdict(Counter)
tribes_all = set(t for _, tr, _ in U.values() for t in tr)
for k in ARMS:
    for l in D[k]:
        pl = {p["seat"]: p for p in l["players"]}
        seen = defaultdict(set)
        for r in l["rounds"]:
            if r["round"] <= 8:
                for u in r["units"]:
                    seen[r["seat"]].add(u["id"])
        for s, p in pl.items():
            ft = p.get("final_tribe")
            for t in tribes_all:
                if ft != t:
                    den[t] += 1
            for cid in seen[s]:
                if cid in U and U[cid][0] in (1, 2):
                    for t in U[cid][1]:
                        if ft != t:
                            held[(cid, t)] += 1
                            by_holder[(cid, t)][p["line"]] += 1
best = {}
for (cid, t), c in held.items():
    sh = c / den[t]
    if t not in best or sh > best[t][1]:
        best[t] = (cid, sh)
print(" denominators:", dict(den))
for t in sorted(best):
    top = sorted(((cid, c / den[tt]) for (cid, tt), c in held.items() if tt == t), key=lambda x: -x[1])[:3]
    print(f"  {t:14s} " + "; ".join(f"{U[c][2]} T{U[c][0]} {s:.3f}" for c, s in top))
    c0 = top[0][0]
    print(f"      holders of {U[c0][2]}: {by_holder[(c0, t)].most_common(4)}")
print(" final_tribe values:", Counter(p.get("final_tribe") for k in ARMS for l in D[k] for p in l["players"]).most_common(10))
# natives ever holding qb_ units (gem receipt proxy)
qn = Counter()
for k in ARMS:
    for l in D[k]:
        for r in l["rounds"]:
            if r["line"] != "line_quilboar_engine" and any(u["id"].startswith("qb_") for u in r["units"]):
                qn[r["line"]] += 1
print(" non-Quilboar seat-rounds holding a qb_ unit:", dict(qn))

tot = Counter()
for (cid, t), c in by_holder.items():
    for ln, n in c.items():
        tot[ln] += n
print("\n off-tribe T1-T2 holdings by holder line (card-seatgame pairs, R1-R8):", tot.most_common(), "total", sum(tot.values()))
