import statistics as st, sys, os, math
from collections import Counter
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from ck_load import *
D = {a: load(a) for a in ["B", "C", "uncut", "frozen"]}
print("# F7 survivor-median round ratios for Q")
for a, L in D.items():
    m = {r: smed(L, r, Q) for r in range(8, 18)}
    print(a, " ".join(f"R{r}:{m[r]/m[r-1]:.2f}" for r in range(9, 17)))
print("\n# F7 biggest one-round jump per seat (cohort alive at R15, R7..R15 present), mode/median round and median size")
for a, L in D.items():
    out = []
    for ln in LINES:
        coh = [s for s in seats(L, ln) if all(r in s["b"] for r in range(7, 16)) and s["b"][7] > 0]
        if not coh: continue
        jr, js = [], []
        for s in coh:
            best = max(range(8, 16), key=lambda r: s["b"][r] / max(1, s["b"][r - 1]))
            jr.append(best); js.append(s["b"][best] / max(1, s["b"][best - 1]))
        c = Counter(jr).most_common(2)
        out.append(f"{NICK[ln]} n{len(coh)} mode R{c[0][0]}({c[0][1]}) 2nd R{c[1][0] if len(c)>1 else '-'} med R{st.median(jr)} size x{st.median(js):.2f}")
    print(a, "\n  " + "\n  ".join(out))
# Alternative: all seats alive at R12 (window R8..R12 only) to check early-jumpers not dropped by the R15 cohort
print("\n# F7 robustness: jump within R8..R15 for all seats alive at R13 (window up to their last round <=15)")
for a, L in D.items():
    out = []
    for ln in [Q, BIRDS, "line_fairies_ring"]:
        coh = [s for s in seats(L, ln) if 13 in s["b"] and s["b"].get(7, 0) > 0]
        jr = []
        for s in coh:
            rr = [r for r in range(8, 16) if r in s["b"]]
            best = max(rr, key=lambda r: s["b"][r] / max(1, s["b"][r - 1]))
            jr.append(best)
        c = Counter(jr).most_common(3)
        out.append(f"{NICK[ln]} n{len(coh)} {c}")
    print(a, out)
print("\n# F8 same cohort alive at R15: R15/R12 median per seat; log share after R12 on survivor medians; Q vs Birds")
for a, L in D.items():
    row = []
    for ln in LINES:
        coh = [s for s in seats(L, ln) if 15 in s["b"] and s["b"].get(12, 0) > 0]
        r1512 = st.median([s["b"][15] / s["b"][12] for s in coh])
        m8, m12, m15 = smed(L, 8, ln), smed(L, 12, ln), smed(L, 15, ln)
        share = math.log(m15 / m12) / math.log(m15 / m8)
        # same cohort log share (alive R15)
        c8 = st.median([s["b"][8] for s in coh]); c12 = st.median([s["b"][12] for s in coh]); c15 = st.median([s["b"][15] for s in coh])
        csh = math.log(c15 / c12) / math.log(c15 / c8)
        row.append(f"{NICK[ln]} R15/R12 x{r1512:.2f} lateshare surv {share:.2f} cohort {csh:.2f}")
    print(a, "\n  " + "\n  ".join(row))
    q = {r: smed(L, r, Q) for r in (12, 14, 15)}; b = {r: smed(L, r, BIRDS) for r in (12, 14, 15)}
    print("  Q/Birds", {r: round(q[r] / b[r], 2) for r in q})
    print("  Q R13->R14 ratio", round(smed(L, 14, Q) / smed(L, 13, Q), 2), "R14->R15", round(smed(L, 15, Q) / smed(L, 14, Q), 2))
print("\n# F9 survivor-median growth R12->R15 per round, per line")
for a, L in D.items():
    print(a, " ".join(f"{NICK[ln]} {gr(smed(L,12,ln), smed(L,15,ln),3):.3f}" for ln in LINES))
print("\n# F10 R15 survivor vs ITT median (eliminated = 0) for Q and Birds; wins; alive share R15")
for a, L in D.items():
    for ln in (Q, BIRDS):
        ss = seats(L, ln)
        sv = smed(L, 15, ln); it = st.median([s["b"].get(15, 0) for s in ss])
        print(a, NICK[ln], "surv", sv, "itt", it, "ratio", round(sv / it, 2) if it else None, "alive15", round(sum(15 in s["b"] for s in ss) / len(ss), 2), "wins", round(sum(s["place"] == 1 for s in ss) / len(ss), 3))
