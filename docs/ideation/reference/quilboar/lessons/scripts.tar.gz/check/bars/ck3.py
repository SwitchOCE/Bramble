import statistics as st, sys, os, math, random
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from ck_load import *
D = {a: load(a) for a in ARMDIR}
print("# F11 Q survivor medians")
for a in ARMDIR:
    print(a, {r: smed(D[a], r, Q) for r in (9, 12, 14, 15)})
def rci(a, b, r, reps=2000, seed=99):
    rng = random.Random(seed); v = []
    A, B = D[a], D[b]
    for _ in range(reps):
        x = smed([A[rng.randrange(len(A))] for _ in A], r, Q); y = smed([B[rng.randrange(len(B))] for _ in B], r, Q)
        if x and y: v.append(x / y)
    v.sort(); return round(v[int(.025 * len(v))], 2), round(v[int(.975 * len(v))], 2)
paper = {"B": {12: 1144, 15: 3363}, "C": {12: 1942, 15: 6123}, "uncut": {12: 6195, 15: 23945}}
for a, b, pa, pb in [("C", "uncut_pre", "C", "uncut"), ("B_pre", "uncut_pre", "B", "uncut"), ("C", "B_pre", "C", "B"), ("B", "uncut", "B", "uncut"), ("C", "B", "C", "B")]:
    for r in (12, 15):
        x, y = smed(D[a], r, Q), smed(D[b], r, Q)
        real = x / y; pp = paper[pa][r] / paper[pb][r]
        print(f"{a}/{b} R{r}: {x}/{y} = {real:.3f} {rci(a,b,r)} paper {pp:.3f}; log-cut real/paper = {math.log(real)/math.log(pp):.2f}")
print("\n# F12 vs BG reference curves (A: Sep 2025 mean; B: Nov 2026 mean; C: Nov 2026 median of perfect-game opponents)")
bgA = {12: 759, 14: 1751}; bgBm = {12: 3505, 14: 6850}; bgC = {12: 2598, 14: 7980}
for a in ("uncut", "uncut_pre", "C", "B"):
    for r in (12, 14):
        x = smed(D[a], r, Q)
        print(a, f"R{r}", x, "xSepMean", round(x / bgA[r], 2), "xNovMean", round(x / bgBm[r], 2), "xNovMedian", round(x / bgC[r], 2))
# Q survivor MEAN vs BG mean (like for like)
for a in ("uncut", "uncut_pre", "C", "B"):
    for r in (12, 14):
        v = [s["b"][r] for s in seats(D[a], Q) if r in s["b"]]
        print(a, f"R{r} Q survivor mean", round(st.mean(v)), "xSepMean", round(st.mean(v) / bgA[r], 2), "xNovMean", round(st.mean(v) / bgBm[r], 2))
print("C R12 vs C target 1800:", round(smed(D['C'], 12, Q) / 1800, 3), "uncut R12/1800", round(smed(D['uncut'],12,Q)/1800,3), round(smed(D['uncut_pre'],12,Q)/1800,3), "uncut/900", round(smed(D['uncut'],12,Q)/900,3), round(smed(D['uncut_pre'],12,Q)/900,3))
# Lobby mean growth R8-R14 without Q vs BG mean growth
for a in ("B", "C", "uncut", "frozen"):
    L = D[a]
    m8 = st.mean(s["b"][8] for s in seats(L, excl=(Q,)) if 8 in s["b"]); m14 = st.mean(s["b"][14] for s in seats(L, excl=(Q,)) if 14 in s["b"])
    print(a, "lobby mean growth w/o Q", round(gr(m8, m14, 6), 3), "lobby mean R12 w/o Q", round(st.mean(s["b"][12] for s in seats(L, excl=(Q,)) if 12 in s["b"])))
