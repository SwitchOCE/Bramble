import statistics as st, sys, os, gzip, json
from collections import Counter
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from ck_load import *
D = {a: load(a) for a in ["B", "C", "uncut", "frozen"]}
print("# F18 in-lobby place gain vs Hard seat (Hard place - line place), seed bootstrap")
for a, L in D.items():
    def gain(S, ln):
        d = []
        for lob in S:
            pl = {s["line"]: s["place"] for s in lob["seats"]}
            d.append(pl["hard"] - pl[ln])
        return st.mean(d)
    row = []
    for ln in (Q, BIRDS, "line_fairies_ring", "line_hedgerow_engine"):
        g = gain(L, ln); ci = boot(L, lambda S: gain(S, ln), reps=1000)
        ss = seats(L, ln)
        row.append(f"{NICK[ln]} {g:+.2f} [{ci[0]:+.2f},{ci[1]:+.2f}] mp {st.mean(s['place'] for s in ss):.2f} win {sum(s['place']==1 for s in ss)/len(ss):.2f} top4 {sum(s['place']<=4 for s in ss)/len(ss):.2f}")
    print(a, "\n  " + "\n  ".join(row))
    # head-to-head: share of lobbies where line finishes above Hard
    print("  Q above Hard share", round(st.mean(1 if {s['line']: s['place'] for s in lob['seats']}[Q] < {s['line']: s['place'] for s in lob['seats']}['hard'] else 0 for lob in L), 2))
print("\n# F19 depth: win shares per line, inside 6-25%, above 25%")
for a, L in D.items():
    w = {NICK[ln]: round(sum(s["place"] == 1 for s in seats(L, ln)) / len(seats(L, ln)), 3) for ln in LINES}
    inside = [k for k, v in w.items() if 0.06 <= v <= 0.25]; above = [k for k, v in w.items() if v > 0.25]
    print(a, w, "inside", len(inside), inside, "above", above)
print("\n# F20 OOM alternatives: best/worst, best/median of other lines, best/second-best (survivor medians, Hard excluded and included)")
for a, L in D.items():
    for r in (12, 14, 15):
        m = {NICK[ln]: smed(L, r, ln) for ln in LINES if ln != "hard"}
        best = max(m, key=m.get); worst = min(m, key=m.get)
        others = [v for k, v in m.items() if k != best]
        srt = sorted(m.values(), reverse=True)
        mh = {NICK[ln]: smed(L, r, ln) for ln in LINES}
        others_h = [v for k, v in mh.items() if k != best]
        alive_worst = sum(r in s["b"] for s in seats(L, [ln for ln in LINES if NICK[ln] == worst][0])) / len(seats(L, [ln for ln in LINES if NICK[ln] == worst][0]))
        print(a, f"R{r}", f"best {best} {m[best]} / worst {worst} {m[worst]} = {m[best]/m[worst]:.1f}x (worst alive {alive_worst:.2f})",
              f"| best / median others = {m[best]/st.median(others):.1f}x (with Hard {mh[best]/st.median(others_h):.1f}x)", f"| best/2nd = {srt[0]/srt[1]:.1f}x")
print("\n# F21 R8 leader win rate CIs from summaries; Q R8 lead share")
for path in [f"{EV}/quilboar-h1-cycle-fix/summary.json.gz"]:
    s = json.load(gzip.open(path))
    for a, v in s["arms"].items():
        print(a, v["round8_leader_win_rate"]["point"], [round(x, 3) for x in v["round8_leader_win_rate"]["ci95"]])
for a, L in D.items():
    lw = []; lw_noq = []; qlead = 0; qwin_rank = []
    for lob in L:
        al = [s for s in lob["seats"] if 8 in s["b"]]
        top = max(s["b"][8] for s in al); ld = [s for s in al if s["b"][8] == top]
        win = [s for s in lob["seats"] if s["place"] == 1][0]
        x = sum(s is win for s in ld) / len(ld); lw.append(x)
        qlead += sum(s["line"] == Q for s in ld) / len(ld)
        rk = sorted(al, key=lambda s: -s["b"][8]).index(win) + 1
        if win["line"] == Q: qwin_rank.append(rk)
        else: lw_noq.append(x)
    print(a, "leader win", round(st.mean(lw), 3), "Q leads", round(qlead / len(L), 3), "Q win R8 rank median", st.median(qwin_rank), "leader win excl Q-won lobbies", round(st.mean(lw_noq), 3), "n", len(lw_noq))
