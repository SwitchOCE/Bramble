import statistics as st, sys, os, gzip, json
from collections import Counter
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from ck_load import *
D = {a: load(a) for a in ["B", "C", "uncut", "frozen"]}
def first_unit(s, cid):
    for r in sorted(s["units"]):
        if cid in s["units"][r]: return r
print("# F15b Hogrider on time (<=R11) vs not by R12, among alive at R12: R12 and R15 board ratio, place, wins")
for a in D:
    a12 = [s for s in seats(D[a], Q) if 12 in s["b"]]
    on = [s for s in a12 if s["ks"] is not None and s["ks"] <= 11]
    at12 = [s for s in a12 if s["ks"] == 12]
    wo = [s for s in a12 if not (s["ks"] is not None and s["ks"] <= 12)]
    def m(x, r): 
        v = [s["b"][r] for s in x if r in s["b"]]; return st.median(v) if v else None
    print(a, f"on-time n{len(on)} R12 {m(on,12)} | at R12 n{len(at12)} R12 {m(at12,12)} | without n{len(wo)} R12 {m(wo,12)}",
          "| on/without R12", round(m(on, 12) / m(wo, 12), 2), "R15", m(on, 15), m(wo, 15), round(m(on, 15) / m(wo, 15), 2) if m(wo, 15) else None,
          f"| on-time mp {st.mean(s['place'] for s in on):.2f} win {sum(s['place']==1 for s in on)/len(on):.2f}")
print("paper staple implied R12/R15: B", round(1/(1-.55),2), round(1/(1-.66),2), "C", round(1/(1-.59),2), round(1/(1-.68),2), "uncut", round(1/(1-.78),2), round(1/(1-.73),2))
print("\n# units on board at R4 / R6 for all lines (B)")
for a in ["B", "uncut"]:
    L = D[a]
    print(a, {NICK[ln]: (round(st.mean(len(s['units'][4]) for s in seats(L, ln)), 2), round(st.mean(len(s['units'][6]) for s in seats(L, ln)), 2)) for ln in LINES})
print("\n# F17 native engine pieces, B arm, survivors at R12, on board by R12")
P = {"line_birds_homecoming": ["mrs_stork"], "line_fairies_ring": ["fairy_monarch"], "line_hedgerow_engine": ["alderman_dozey"],
     "line_bog_engine": ["jenny_greenteeth", "vaulting_hopkin", "peat_king"], "line_hunters_engine": ["brother_wolf", "grizel"], "line_oozes_engine": ["mr_syllabub", "elder_ooze"]}
for a in ["B", "uncut"]:
    for ln, ps in P.items():
        a12 = [s for s in seats(D[a], ln) if 12 in s["b"]]
        for p in ps:
            fr = [first_unit(s, p) for s in a12]
            w = [s for s, f in zip(a12, fr) if f is not None and f <= 12]; wo = [s for s, f in zip(a12, fr) if not (f is not None and f <= 12)]
            def ps_(x): return f"n{len(x)} mp {st.mean(s['place'] for s in x):.2f} win {sum(s['place']==1 for s in x)/len(x):.2f}" if x else "n0"
            g = [f for f in fr if f is not None and f <= 12]
            # tier of the round it first landed and the seat's tier at R9
            print(a, NICK[ln], p, f"share {len(w)/len(a12):.2f} (of all seats {len(w)/len(seats(D[a], ln)):.2f}) median first R{st.median(g) if g else '-'}", "with", ps_(w), "| without", ps_(wo))
print("\n# Hedgerow: does Dozey arrival track early strength? R9 board and tier at R9, with vs without Dozey by R12")
for a in ["B", "uncut"]:
    a12 = [s for s in seats(D[a], "line_hedgerow_engine") if 12 in s["b"]]
    w = [s for s in a12 if (first_unit(s, "alderman_dozey") or 99) <= 12]; wo = [s for s in a12 if (first_unit(s, "alderman_dozey") or 99) > 12]
    for nm, x in (("with", w), ("without", wo)):
        print(a, nm, "R9 board med", st.median(s["b"][9] for s in x), "tier R9 mean", round(st.mean(s["tier"][9] for s in x), 2), "tier R11 mean", round(st.mean(s["tier"][11] for s in x), 2), "R12 board", st.median(s['b'][12] for s in x))
    fr = [first_unit(s, "alderman_dozey") for s in w]
    print(a, "Dozey first rounds", sorted(Counter(fr).items()), "tier when first landed", Counter(s["tier"][first_unit(s, "alderman_dozey")] for s in w))
