import statistics as st, sys, os
from collections import Counter
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from ck_load import *
D = {a: load(a) for a in ["B", "C", "uncut", "frozen", "B_pre", "uncut_pre"]}
def first_unit(s, cid):
    for r in sorted(s["units"]):
        if cid in s["units"][r]: return r
def first_tier(s, t):
    for r in sorted(s["tier"]):
        if s["tier"][r] >= t: return r
def q(xs, p):
    xs = sorted(xs); return xs[int(p * len(xs))] if xs else None
print("# F13 arrivals among Quilboar seats")
for a in ["B", "C", "uncut", "frozen"]:
    ss = seats(D[a], Q); n = len(ss)
    out = [a, f"n{n}"]
    for name, fn in [("T5", lambda s: first_tier(s, 5)), ("T6", lambda s: first_tier(s, 6)), ("Tunneler", lambda s: first_unit(s, "qb_bramble_tunneler")),
                     ("GemRat", lambda s: first_unit(s, "qb_gem_rat")), ("Refiner", lambda s: first_unit(s, "qb_sanguine_refiner")),
                     ("HogBoard", lambda s: first_unit(s, "qb_turbo_hogrider")), ("HogKS", lambda s: s["ks"])]:
        v = [fn(s) for s in ss]; g = [x for x in v if x is not None]
        by11 = sum(1 for x in g if x <= 11) / n; by12 = sum(1 for x in g if x <= 12) / n
        a12 = [s for s in ss if 12 in s["b"]]
        by12a = sum(1 for s in a12 if fn(s) is not None and fn(s) <= 12) / len(a12)
        out.append(f"{name}: med R{st.median(g)} IQR R{q(g,.25)}-R{q(g,.75)} ever {len(g)/n:.2f} by11 {by11:.2f} by12 {by12:.2f} (alive12 {by12a:.2f})")
    print("\n  ".join(out))
print("\n# F14 on-time Hogrider seats (KS <= 11): R12 and R15 survivor medians")
paper = {"B": (1144, 3363), "uncut": (6195, 23945), "C": (1942, 6123)}
for a in ["B", "C", "uncut"]:
    ss = [s for s in seats(D[a], Q) if s["ks"] is not None and s["ks"] <= 11]
    m12 = st.median([s["b"][12] for s in ss if 12 in s["b"]]); m15 = st.median([s["b"][15] for s in ss if 15 in s["b"]])
    n15 = sum(15 in s["b"] for s in ss)
    print(a, "n", len(ss), "R12", m12, round(m12 / paper[a][0], 2), "R15", m15, f"(n15={n15})", round(m15 / paper[a][1], 2))
print("\n# F15 with/without Hogrider by R12 among Q seats alive at R12; late buckets")
for a in ["B", "C", "uncut", "frozen"]:
    a12 = [s for s in seats(D[a], Q) if 12 in s["b"]]
    w = [s for s in a12 if s["ks"] is not None and s["ks"] <= 12]; wo = [s for s in a12 if not (s["ks"] is not None and s["ks"] <= 12)]
    late = [s for s in a12 if s["ks"] is not None and s["ks"] >= 13]; never = [s for s in a12 if s["ks"] is None]
    def stat(x):
        return f"n{len(x)} mp {st.mean(s['place'] for s in x):.2f} win {sum(s['place']==1 for s in x)/len(x):.2f} R12 {st.median([s['b'][12] for s in x])}" if x else "n0"
    print(a, "with", stat(w), "| without", stat(wo), "| ratio R12", round(st.median([s['b'][12] for s in w]) / st.median([s['b'][12] for s in wo]), 2), "| late>=13", stat(late), "| never", stat(never))
print("\n# F16 Quilboar early: units on board R4/R6 (active), R9 survivor medians, out before R12, B places")
for a in ["B", "C", "uncut", "frozen"]:
    L = D[a]
    def u(line, r):
        return st.mean(len(s["units"][r]) for s in seats(L, line) if r in s["units"])
    out12 = {NICK[ln]: round(sum(12 not in s["b"] for s in seats(L, ln)) / len(seats(L, ln)), 2) for ln in (Q, BIRDS, "hard")}
    pl = Counter(s["place"] for s in seats(L, Q)); n = len(seats(L, Q))
    print(a, f"units R4 Q {u(Q,4):.2f} Hard {u('hard',4):.2f} Birds {u(BIRDS,4):.2f}; R6 Q {u(Q,6):.2f} Hard {u('hard',6):.2f}", "R9 Q/Hard/Birds", smed(L, 9, Q), smed(L, 9, "hard"), smed(L, 9, BIRDS), "out<R12", out12,
          "wins", round(pl[1] / n, 2), "bottom4", round(sum(pl[k] for k in (5, 6, 7, 8)) / n, 2), "places", sorted(pl.items()))
    # out before R12 for all lines
    print("   out<R12 all lines", {NICK[ln]: round(sum(12 not in s["b"] for s in seats(L, ln)) / len(seats(L, ln)), 2) for ln in LINES})
