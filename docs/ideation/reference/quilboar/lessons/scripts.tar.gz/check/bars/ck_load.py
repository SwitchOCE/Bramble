"""Independent loader for the Quilboar H1 compact archives (skeptic check). Read-only."""
import glob, gzip, json, os, random, statistics as st

EV = "/home/alex/code/Bramble-ideation-sol/tools/sim/evidence"
ARMDIR = {
    "B": f"{EV}/quilboar-h1-cycle-fix/B",
    "C": f"{EV}/quilboar-h1/C",
    "uncut": f"{EV}/quilboar-h1-cycle-fix/uncut",
    "frozen": f"{EV}/quilboar-h1/uncut_frozen",
    "B_pre": f"{EV}/quilboar-h1/B",
    "uncut_pre": f"{EV}/quilboar-h1/uncut",
}
Q = "line_quilboar_engine"
BIRDS = "line_birds_homecoming"
LINES = [Q, BIRDS, "line_fairies_ring", "line_bog_engine", "line_hedgerow_engine",
         "line_hunters_engine", "line_oozes_engine", "hard"]
NICK = dict(zip(LINES, ["Q", "Birds", "Fairies", "Bog", "Hedge", "Hunt", "Ooze", "Hard"]))


def load(arm):
    out = []
    for f in sorted(glob.glob(os.path.join(ARMDIR[arm], "*.lobbies.json.gz"))):
        with gzip.open(f) as fh:
            games = json.load(fh)
        for g in games:
            seats = {p["seat"]: dict(line=p["line"], place=p["place"], nrounds=p["rounds"], b={}, tier={}, units={}, ks=[])
                     for p in g["players"]}
            last = 0
            for r in g["rounds"]:
                s = seats[r["seat"]]
                s["b"][r["round"]] = r["stats"]
                s["tier"][r["round"]] = r["tier"]
                s["units"][r["round"]] = [u["id"] for u in r["units"] if u.get("active", True)]
                if r.get("keystone_found_round"):
                    s["ks"].append(r["keystone_found_round"])
                last = max(last, r["round"])
            for s in seats.values():
                s["ks"] = min(s["ks"]) if s["ks"] else None
                s["last_game_round"] = last
            out.append(dict(seed=g["seed"], seats=list(seats.values()), last=last))
    return out


def seats(L, line=None, excl=()):
    return [s for lob in L for s in lob["seats"] if (line is None or s["line"] == line) and s["line"] not in excl]


def smed(L, r, line=None, excl=()):
    v = [s["b"][r] for s in seats(L, line, excl) if r in s["b"]]
    return st.median(v) if v else None


def gr(a, b, n):
    return (b / a) ** (1 / n) if a and b and a > 0 and b > 0 else None


def boot(L, fn, reps=1000, seed=12345):
    rng = random.Random(seed)
    v = []
    for _ in range(reps):
        S = [L[rng.randrange(len(L))] for _ in L]
        x = fn(S)
        if x is not None:
            v.append(x)
    v.sort()
    return v[int(0.025 * len(v))], v[min(len(v) - 1, int(0.975 * len(v)))]
