import gzip, json, statistics as st, sys, os
from collections import Counter
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from ck_load import *
D = {a: load(a) for a in ARMDIR}
ARMS = ["B", "C", "uncut", "frozen", "B_pre", "uncut_pre"]
print("lobbies", {a: len(D[a]) for a in ARMS})
# summary values
for path, arms in [(f"{EV}/quilboar-h1-cycle-fix/summary.json.gz", None), (f"{EV}/quilboar-h1/summary.json.gz", None)]:
    s = json.load(gzip.open(path))
    for a, v in s["arms"].items():
        print(path.split('/')[-2], a, round(v["all_seat_growth_r8_r14"]["point"], 4), [round(x, 3) for x in v["all_seat_growth_r8_r14"]["ci95"]], "r8lead", v["round8_leader_win_rate"]["point"])
print("\n# F1/F2 lobby median growth, without Q, mean growth, mean growth without Q")
for a in ARMS:
    L = D[a]
    g = gr(smed(L, 8), smed(L, 14), 6)
    gq = gr(smed(L, 8, excl=(Q,)), smed(L, 14, excl=(Q,)), 6)
    m8 = st.mean(s["b"][8] for s in seats(L) if 8 in s["b"]); m14 = st.mean(s["b"][14] for s in seats(L) if 14 in s["b"])
    m8q = st.mean(s["b"][8] for s in seats(L, excl=(Q,)) if 8 in s["b"]); m14q = st.mean(s["b"][14] for s in seats(L, excl=(Q,)) if 14 in s["b"])
    surv14 = sorted((s["b"][14], NICK[s["line"]]) for s in seats(L) if 14 in s["b"])
    mid = len(surv14) // 2
    near = Counter(x[1] for x in surv14[mid - 10: mid + 10])
    print(a, "med", round(g, 4), "noQ", round(gq, 4), "diff", round(g - gq, 3), "mean", round(gr(m8, m14, 6), 3), "meanNoQ", round(gr(m8q, m14q, 6), 3),
          "Q R14", smed(L, 14, Q), "R14 median", smed(L, 14), "near median", dict(near.most_common(5)))
print("\n# F3 per-line survivor growth R8-R14, same-cohort per-seat median, alive R14")
for a in ["B", "C", "uncut", "frozen"]:
    L = D[a]; row = []
    for ln in LINES:
        sg = gr(smed(L, 8, ln), smed(L, 14, ln), 6)
        coh = [s for s in seats(L, ln) if 14 in s["b"] and s["b"].get(8, 0) > 0]
        cg = st.median([(s["b"][14] / s["b"][8]) ** (1 / 6) for s in coh])
        row.append(f"{NICK[ln]} {sg:.3f}/{cg:.3f} n{len(coh)}")
    print(a, "; ".join(row))
print("\n# Q per-line growth CIs")
for a in ["B", "uncut", "frozen"]:
    L = D[a]
    print(a, boot(L, lambda S: gr(smed(S, 8, Q), smed(S, 14, Q), 6)))
print("\n# F4 frozen Q vs Birds: mean place, wins, alive R14, same-cohort growth, R14 survivors median, ITT-ish")
for a in ["frozen", "B", "uncut", "C"]:
    L = D[a]
    for ln in (Q, BIRDS):
        ss = seats(L, ln)
        mp = st.mean(s["place"] for s in ss); w = sum(s["place"] == 1 for s in ss) / len(ss)
        al = sum(14 in s["b"] for s in ss)
        coh = [s for s in ss if 14 in s["b"] and s["b"].get(8, 0) > 0]
        cg = st.median([(s["b"][14] / s["b"][8]) ** (1 / 6) for s in coh])
        print(a, NICK[ln], "mp", round(mp, 2), "wins", round(w, 3), "alive14", al, "/", len(ss), "cohort g", round(cg, 3), "R8", smed(L, 8, ln), "R14", smed(L, 14, ln))
print("\n# game length (last round any seat plays)")
for a in ["B", "C", "uncut", "frozen"]:
    c = Counter(l["last"] for l in D[a]); print(a, sorted(c.items()))
print("\n# F5 window dependence: lobby survivor median vs same cohort per-seat median, and ITT median")
for a in ["B", "C", "uncut", "frozen"]:
    L = D[a]
    for x, y in [(8, 14), (9, 15), (10, 16), (12, 15)]:
        sm = gr(smed(L, x), smed(L, y), y - x)
        coh = [s for s in seats(L) if y in s["b"] and s["b"].get(x, 0) > 0]
        cg = st.median([(s["b"][y] / s["b"][x]) ** (1 / (y - x)) for s in coh])
        # cohort ratio of medians (same seats) as alternative
        cr = gr(st.median([s["b"][x] for s in coh]), st.median([s["b"][y] for s in coh]), y - x)
        allv = [s["b"].get(y, 0) for s in seats(L)]
        # alive-or-game-over: count winners of finished games at their last board instead of 0
        alive_y = sum(y in s["b"] for s in seats(L)) / len(seats(L))
        print(a, f"R{x}-R{y}", "surv", round(sm, 3), "cohort per-seat med", round(cg, 3), "cohort ratio of medians", round(cr, 3), "n", len(coh), "alive share at end", round(alive_y, 2), "ITT med end", st.median(allv))
