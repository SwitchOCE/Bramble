"""Native legacy engine pieces on board by R12 vs place; same with seats alive at R13. Run: python3 -I ck_pieces.py"""
import glob, gzip, json, os
from collections import defaultdict
HERE = os.path.dirname(os.path.abspath(__file__))
EV = "/home/alex/code/Bramble-ideation-sol/tools/sim/evidence"
ARMS = {"B_post": EV + "/quilboar-h1-cycle-fix/B", "C_pre": EV + "/quilboar-h1/C",
        "uncut_post": EV + "/quilboar-h1-cycle-fix/uncut", "frozen_pre": EV + "/quilboar-h1/uncut_frozen"}
P = json.load(open(HERE + "/content-bb8bb5f2/line_profiles.committed.json"))
for k, v in ARMS.items():
    L = []
    for f in sorted(glob.glob(v + "/*.lobbies.json.gz")):
        L.extend(json.load(gzip.open(f, "rt")))
    out = []
    for line in ("line_bog_engine", "line_hedgerow_engine", "line_hunters_engine", "line_oozes_engine"):
        pcs = set(P[line]["engine_pieces"])
        w, wo, aw, awo = [], [], [], []
        for l in L:
            by = defaultdict(dict)
            for r in l["rounds"]:
                by[r["seat"]][r["round"]] = r
            for p in l["players"]:
                if p["line"] != line:
                    continue
                s = by[p["seat"]]
                has = any(u["id"] in pcs for rr in s if rr <= 12 for u in s[rr]["units"] if u.get("active", True))
                (w if has else wo).append(p["place"])
                if 13 in s:
                    (aw if has else awo).append(p["place"])
        m = lambda x: sum(x) / len(x) if x else float("nan")
        out.append(f"{line[5:9]} share {len(w)/(len(w)+len(wo)):.2f} gap {m(wo)-m(w):.2f} | alive13 gap {m(awo)-m(aw):.2f} (n without {len(awo)})")
    print(k, " ; ".join(out))
