"""Skeptic's second compact pass: Hogrider (F13), gem size (F15), hazard cards (F17), cohort growth (F8), spread levels (F5).
Run: python3 -I ck_compact2.py > ck_compact2.txt
"""
import glob, gzip, json, math, statistics
from collections import Counter, defaultdict

EV = "/home/alex/code/Bramble-ideation-sol/tools/sim/evidence"
ARMS = {
    "B_pre": EV + "/quilboar-h1/B", "C_pre": EV + "/quilboar-h1/C",
    "uncut_pre": EV + "/quilboar-h1/uncut", "frozen_pre": EV + "/quilboar-h1/uncut_frozen",
    "B_post": EV + "/quilboar-h1-cycle-fix/B", "uncut_post": EV + "/quilboar-h1-cycle-fix/uncut",
}
CANON = ["B_post", "C_pre", "uncut_post", "frozen_pre"]
Q = "line_quilboar_engine"
LINES = [Q, "line_birds_homecoming", "line_fairies_ring", "line_bog_engine", "line_hedgerow_engine",
         "line_hunters_engine", "line_oozes_engine", "hard"]
S = dict(zip(LINES, ["Quil", "Birds", "Fairies", "Bog", "Hedge", "Hunters", "Oozes", "Hard"]))
med = statistics.median


def load(folder):
    out = []
    for f in sorted(glob.glob(folder + "/*.lobbies.json.gz")):
        out.extend(json.load(gzip.open(f, "rt")))
    return out


def q(xs, p):
    xs = sorted(xs); k = (len(xs) - 1) * p; lo = math.floor(k); hi = min(lo + 1, len(xs) - 1)
    return xs[lo] + (xs[hi] - xs[lo]) * (k - lo)


D = {k: load(v) for k, v in ARMS.items()}


def seats(l):
    by = defaultdict(dict)
    for r in l["rounds"]:
        by[r["seat"]][r["round"]] = r
    return by


print("=== F13 Hogrider by R12 (units on board by R12, and keystone_found_round<=12)")
for k in CANON:
    rows = []
    for l in D[k]:
        by = seats(l)
        for p in l["players"]:
            if p["line"] != Q:
                continue
            s = by[p["seat"]]
            on = any(u["id"] == "qb_turbo_hogrider" for rr in s for u in s[rr]["units"] if rr <= 12)
            kf = [s[rr].get("keystone_found_round") for rr in s if s[rr].get("keystone_found_round") is not None]
            kfr = min(kf) if kf else None
            rows.append(dict(place=p["place"], on=on, kf=(kfr is not None and kfr <= 12), alive13=13 in s, rounds=p["rounds"]))
    for key in ("on", "kf"):
        w = [r["place"] for r in rows if r[key]]; wo = [r["place"] for r in rows if not r[key]]
        a = [r for r in rows if r["alive13"]]
        aw = [r["place"] for r in a if r[key]]; awo = [r["place"] for r in a if not r[key]]
        print(f"  {k:10s} by {key}: share {len(w)/len(rows):.2f} mean place {sum(w)/len(w):.2f} / {sum(wo)/len(wo):.2f}  first {sum(x==1 for x in w)/len(w):.2f}/{sum(x==1 for x in wo)/len(wo):.2f} | alive R13 n={len(a)} share {len(aw)/len(a):.2f} place {sum(aw)/len(aw):.2f} (n={len(aw)}) / {sum(awo)/len(awo):.2f} (n={len(awo)})")
    # sanity: mean place of all Quil seats alive at R13, and how many places are available
    a = [r["place"] for r in rows if r["alive13"]]
    print(f"     all alive-R13 Quil seats: n={len(a)}, mean place {sum(a)/len(a):.2f}, place dist {sorted(Counter(a).items())}")

print("\n=== F15 gem size at R9/R12/R15 (gem_size halves -> /2), Quil seat")
for k in CANON:
    cells = []
    for r in (6, 9, 12, 15):
        g = [x["gem_size"] for l in D[k] for x in l["rounds"] if x["line"] == Q and x["round"] == r]
        cells.append(f"R{r} {med([a for a, b in g])/2}/{med([b for a, b in g])/2}")
    print(f"  {k:10s} " + "  ".join(cells))

print("\n=== F17 hazard / splash cards held by the Quil seat at any round (seat-games)")
ids = Counter()
for k in CANON:
    for l in D[k]:
        by = seats(l)
        for p in l["players"]:
            if p["line"] != Q:
                continue
            held = set(u["id"] for rr in by[p["seat"]] for u in by[p["seat"]][rr]["units"])
            for i in held:
                ids[i] += 1
nq = sum(1 for k in CANON for l in D[k] for p in l["players"] if p["line"] == Q)
print("  Quil seat-games:", nq)
for i, c in sorted(ids.items(), key=lambda x: -x[1]):
    if not i.startswith("qb_"):
        pass
hz = [i for i in ids if any(w in i for w in ("busker", "silky", "sexton", "whirligig", "pipistrelle", "echo", "soup", "click", "felboar", "barrage", "bonker", "roadboar"))]
for i in sorted(hz):
    print(f"  {i}: {ids[i]}")
print("  qb_ ids seen:", sorted(i for i in ids if i.startswith("qb_")))

print("\n=== F8 same cohort (alive at R15): per-round growth R8->R12 vs R12->R15")
for k in CANON:
    cells = []
    for line in LINES:
        a, b = [], []
        for l in D[k]:
            by = seats(l)
            for p in l["players"]:
                if p["line"] != line:
                    continue
                s = by[p["seat"]]
                if all(x in s for x in (8, 12, 15)) and s[8]["stats"] > 0 and s[12]["stats"] > 0:
                    a.append((s[12]["stats"] / s[8]["stats"]) ** 0.25)
                    b.append((s[15]["stats"] / s[12]["stats"]) ** (1 / 3))
        cells.append(f"{S[line]} {med(a):.2f}->{med(b):.2f}")
    print(f"  {k:10s} " + "  ".join(cells))

print("\n=== F5 Quil R12 p10/p50/p90 levels vs paper low/typical/strong")
paper = {"B_post": (308, 1144, 1698), "C_pre": (423, 1942, 2992), "uncut_post": (502, 6195, 11057), "B_pre": (308, 1144, 1698), "uncut_pre": (502, 6195, 11057)}
for k, (lo, ty, st) in paper.items():
    x = [r["stats"] for l in D[k] for r in l["rounds"] if r["line"] == Q and r["round"] == 12]
    print(f"  {k:10s} p10 {q(x,.1):.0f} ({q(x,.1)/lo:.2f}x paper low)  p50 {q(x,.5):.0f} ({q(x,.5)/ty:.2f}x typical)  p90 {q(x,.9):.0f} ({q(x,.9)/st:.2f}x strong)  p90/p10 {q(x,.9)/q(x,.1):.1f} vs paper {st/lo:.1f}; p75/p25 {q(x,.75)/q(x,.25):.1f}")
