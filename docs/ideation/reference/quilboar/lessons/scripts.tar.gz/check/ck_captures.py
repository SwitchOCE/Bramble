"""Skeptic's independent recompute from the local captures, hash-checked against committed receipts.
Run: python3 -I ck_captures.py > ck_captures.txt
"""
import glob, gzip, hashlib, json, math, os, pickle, statistics
from collections import Counter, defaultdict

SOL = "/home/alex/code/Bramble-ideation-sol"
EV = SOL + "/tools/sim/evidence"
RUNS = {
    "B_pre": ("quilboar-h1", "B"), "C_pre": ("quilboar-h1", "C"),
    "uncut_pre": ("quilboar-h1", "uncut"), "frozen_pre": ("quilboar-h1", "uncut_frozen"),
    "B_post": ("quilboar-h1-cycle-fix", "B"), "uncut_post": ("quilboar-h1-cycle-fix", "uncut"),
}
CANON = ["B_post", "C_pre", "uncut_post", "frozen_pre"]
Q = "line_quilboar_engine"
NAT = ["line_birds_homecoming", "line_fairies_ring", "line_bog_engine", "line_hedgerow_engine",
       "line_hunters_engine", "line_oozes_engine", "hard"]
S = dict(zip([Q] + NAT, ["Quil", "Birds", "Fairies", "Bog", "Hedge", "Hunters", "Oozes", "Hard"]))
CACHE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "ck_fights.pkl")
med = statistics.median


def load():
    if os.path.exists(CACHE):
        return pickle.load(open(CACHE, "rb"))
    F, chk = {}, {}
    for key, (run, arm) in RUNS.items():
        rec = json.load(open(f"{EV}/{run}/{arm}/receipt.json"))
        ok = bad = 0
        rows = []
        for c in rec["chunks"]:
            p = SOL + "/" + c["capture"]
            b = open(p, "rb").read()
            if hashlib.sha256(b).hexdigest() != c["capture_gzip_sha256"]:
                bad += 1
                continue
            ok += 1
            for line in gzip.decompress(b).decode().splitlines():
                x = json.loads(line)
                if -1 in x["players"]:
                    continue
                cs = x["combat_start"]
                rows.append(dict(
                    seed=x["seed"], round=x["round"], players=x["players"], leg=x["leg"],
                    lines=[c_["assigned_line"] for c_ in cs], stats=[c_["active_stats"] for c_ in cs],
                    post=[a["active_stats"] for a in x["after_start_effects"]],
                    share=[c_["largest_share"] for c_ in cs], winner=x["outcome"]["winner"],
                    ring=[fr.get("ring_size") for fr in x["input"]["fight_rules"]],
                    ringcount=[sum(it.get("count", 0) for slot in x["input"]["slots"][i] for it in (slot or []) if isinstance(it, dict) and it.get("name") == "Ring") for i in range(2)],
                ))
        F[key] = rows
        chk[key] = (ok, bad, len(rec["chunks"]))
    pickle.dump((F, chk), open(CACHE, "wb"))
    return F, chk


F, chk = load()
print("hash check (ok, bad, chunks):", chk)
print("winner codes B_post:", Counter(f["winner"] for f in F["B_post"]), "legs:", Counter(f["leg"] for f in F["B_post"]))


def sc(f, i):
    w = f["winner"]
    return 1.0 if w == i else (0.0 if w in (0, 1) else 0.5)


def rate(xs):
    return f"{sum(xs)/len(xs):.2f} (n={len(xs)})" if xs else "-"


def band(r):
    return "R6-8" if r <= 8 else "R9-11" if r <= 11 else "R12-14" if r <= 14 else "R15+"


def eqt(a, b):
    return b > 0 and 0.8 <= a / b <= 1.25


print("\n=== F9/Q5: Quilboar win rate vs all opponents by band (draw=1/2)")
for k in CANON:
    cells = []
    for bd in ("R6-8", "R9-11", "R12-14", "R15+"):
        xs = [sc(f, f["lines"].index(Q)) for f in F[k] if f["round"] >= 6 and band(f["round"]) == bd and Q in f["lines"] and f["lines"][0] != f["lines"][1]]
        cells.append(f"{bd} {rate(xs)}")
    print(f"  {k:10s} " + "  ".join(cells))
    # draws share
xs = [f["winner"] for f in F["B_post"] if f["round"] >= 9]
print("  draw share R9+ B_post:", sum(w == -1 for w in xs) / len(xs))

print("\n=== F3: frozen Quilboar vs Birds head to head by band")
for k in ("frozen_pre", "uncut_pre"):
    cells = []
    for bd in ("R6-8", "R9-11", "R12-14", "R15+"):
        xs = [sc(f, f["lines"].index(Q)) for f in F[k] if f["round"] >= 6 and band(f["round"]) == bd and Q in f["lines"] and "line_birds_homecoming" in f["lines"]]
        cells.append(f"{bd} {rate(xs)}")
    print(f"  {k:10s} " + "  ".join(cells))

print("\n=== F6: equal pre-start totals (0.8-1.25), R9+")
for k in CANON:
    xs = [sc(f, f["lines"].index(Q)) for f in F[k] if f["round"] >= 9 and Q in f["lines"] and eqt(f["stats"][f["lines"].index(Q)], f["stats"][1 - f["lines"].index(Q)])]
    xp = [sc(f, f["lines"].index(Q)) for f in F[k] if f["round"] >= 9 and Q in f["lines"] and eqt(f["post"][f["lines"].index(Q)], f["post"][1 - f["lines"].index(Q)])]
    # native-native wider side
    ww, wp = [], []
    for f in F[k]:
        if f["round"] < 9 or Q in f["lines"]:
            continue
        if abs(f["share"][0] - f["share"][1]) < 0.05:
            continue
        wide = 0 if f["share"][0] < f["share"][1] else 1
        if eqt(f["stats"][0], f["stats"][1]):
            ww.append(sc(f, wide))
        if eqt(f["post"][0], f["post"][1]):
            wp.append(sc(f, wide))
    # Quilboar by band
    byb = defaultdict(list)
    for f in F[k]:
        if f["round"] >= 6 and Q in f["lines"]:
            i = f["lines"].index(Q)
            if eqt(f["stats"][i], f["stats"][1 - i]):
                byb[band(f["round"])].append(sc(f, i))
    print(f"  {k:10s} Quil pre-start eq {rate(xs)} | post-start eq {rate(xp)} | native wider side pre {rate(ww)} post {rate(wp)} | bands " + " ".join(f"{b} {rate(v)}" for b, v in sorted(byb.items())))

print("\n  Quilboar win rate by own/opp pre-start ratio, R9+ (break-even search)")
BINS = [(0.5, 0.67), (0.67, 0.8), (0.8, 1.0), (1.0, 1.25), (1.25, 1.5), (1.5, 2.0), (2.0, 4.0)]
for k in CANON:
    cells = []
    for lo, hi in BINS:
        xs = [sc(f, f["lines"].index(Q)) for f in F[k] if f["round"] >= 9 and Q in f["lines"] and min(f["stats"]) > 0 and lo <= f["stats"][f["lines"].index(Q)] / f["stats"][1 - f["lines"].index(Q)] < hi]
        cells.append(f"{lo}-{hi}: {rate(xs)}")
    print(f"  {k:10s} " + "  ".join(cells))
print("  native-native, win rate of side A by A/B ratio (both orientations), R9+")
for k in CANON:
    cells = []
    for lo, hi in BINS:
        xs = []
        for f in F[k]:
            if f["round"] < 9 or Q in f["lines"] or min(f["stats"]) <= 0:
                continue
            for i in (0, 1):
                r = f["stats"][i] / f["stats"][1 - i]
                if lo <= r < hi:
                    xs.append(sc(f, i))
        cells.append(f"{lo}-{hi}: {rate(xs)}")
    print(f"  {k:10s} " + "  ".join(cells))

print("\n  per-line win rate at equal pre-start totals R9+: vs Quilboar / vs other natives (different line)")
for k in CANON:
    cells = []
    for me in NAT:
        vq = [sc(f, f["lines"].index(me)) for f in F[k] if f["round"] >= 9 and me in f["lines"] and Q in f["lines"] and eqt(f["stats"][f["lines"].index(me)], f["stats"][1 - f["lines"].index(me)])]
        vn = [sc(f, f["lines"].index(me)) for f in F[k] if f["round"] >= 9 and me in f["lines"] and Q not in f["lines"] and f["lines"][0] != f["lines"][1] and eqt(f["stats"][f["lines"].index(me)], f["stats"][1 - f["lines"].index(me)])]
        cells.append(f"{S[me]} {rate(vq)} / {rate(vn)}")
    print(f"  {k:10s} " + " | ".join(cells))

print("\n  Quilboar at equal totals by opponent biggest-unit share, R9+")
for k in CANON:
    cells = []
    for lo, hi in ((0, 0.3), (0.3, 0.4), (0.4, 1.01)):
        xs = [sc(f, f["lines"].index(Q)) for f in F[k] if f["round"] >= 9 and Q in f["lines"] and eqt(f["stats"][f["lines"].index(Q)], f["stats"][1 - f["lines"].index(Q)]) and lo <= f["share"][1 - f["lines"].index(Q)] < hi]
        cells.append(f"{lo}-{hi}: {rate(xs)}")
    print(f"  {k:10s} " + "  ".join(cells))

print("\n=== F11: R12-R15 lopsided (>=1.5x) share and bigger-side win rate")
for k in CANON:
    allf = [f for f in F[k] if 12 <= f["round"] <= 15 and min(f["stats"]) > 0 and f["lines"][0] != f["lines"][1] or (12 <= f["round"] <= 15 and min(f["stats"]) > 0 and f["lines"][0] == f["lines"][1])]
    def lop(fs):
        b = [f for f in fs if max(f["stats"]) / min(f["stats"]) >= 1.5]
        w = [sc(f, 0 if f["stats"][0] >= f["stats"][1] else 1) for f in b]
        return f"{len(b)/len(fs):.2f} of {len(fs)}, bigger wins {sum(w)/len(w):.3f}"
    nn = [f for f in allf if Q not in f["lines"]]
    qf = [f for f in allf if Q in f["lines"]]
    # native-only, excluding Hard
    nn2 = [f for f in nn if "hard" not in f["lines"]]
    # bigger side's win rate in NON-lopsided native fights (baseline of how decisive stats are)
    nl = [sc(f, 0 if f["stats"][0] >= f["stats"][1] else 1) for f in nn if max(f["stats"]) / min(f["stats"]) < 1.5]
    print(f"  {k:10s} all {lop(allf)} | Quil {lop(qf)} | native-only {lop(nn)} | native no Hard {lop(nn2)} | native <1.5x bigger wins {sum(nl)/len(nl):.2f}")
    # by round
    for r in (12, 15):
        fs = [f for f in nn if f["round"] == r]
        print(f"      native-only R{r}: {lop(fs)}")

print("\n=== F10: win rate in the fight of a x2 round vs other fights R8+ (prev pre-start board >=30), from captures")
for k in CANON:
    by = defaultdict(dict)
    for f in F[k]:
        for i in (0, 1):
            by[(f["seed"], f["players"][i])][f["round"]] = (f["stats"][i], sc(f, i), f["lines"][i], f["stats"][1 - i])
    cells = []
    for line in (Q, "line_birds_homecoming", "line_fairies_ring", "line_hedgerow_engine"):
        j, o, jr = [], [], []
        for key, rs in by.items():
            for r, (st, s, ln, opp) in rs.items():
                if r < 8 or ln != line or (r - 1) not in rs:
                    continue
                pv = rs[r - 1][0]
                if pv >= 30:
                    if st / pv >= 2:
                        j.append(s)
                        if opp > 0:
                            jr.append(st / opp)
                    else:
                        o.append(s)
        cells.append(f"{S[line]} jump {rate(j)} other {rate(o)} jump-fight own/opp median {med(jr):.2f}" if jr else f"{S[line]} -")
    print(f"  {k:10s} " + " | ".join(cells))

print("\n=== F15: Fairies' ring_size and Ring count by round (from fight_rules / slots)")
for k in CANON:
    cells = []
    for r in (9, 12, 15):
        rs = [f["ring"][i] for f in F[k] if f["round"] == r for i in (0, 1) if f["lines"][i] == "line_fairies_ring" and f["ring"][i] is not None]
        rc = [f["ringcount"][i] for f in F[k] if f["round"] == r for i in (0, 1) if f["lines"][i] == "line_fairies_ring"]
        cells.append(f"R{r} size {med(rs) if rs else '-'} n={len(rs)} rings {med(rc) if rc else '-'}")
    print(f"  {k:10s} " + "; ".join(cells))
