"""Size freeze: pre-fix uncut against frozen, survivors and all seats (dead=0), R12/R15. python3 -I ck_size.py"""
import gzip, json, glob, statistics as st
EV='/home/alex/code/Bramble-ideation-sol/tools/sim/evidence/quilboar-h1'
def q(arm):
    out=[]
    for f in sorted(glob.glob(f'{EV}/{arm}/*.lobbies.json.gz')):
        for g in json.load(gzip.open(f)):
            for p in g['players']:
                if p['line']=='line_quilboar_engine':
                    out.append({r['round']:r['stats'] for r in g['rounds'] if r['seat']==p['seat']})
    return out
U=q('uncut'); F=q('uncut_frozen')
for R in (12,15):
    su=[s[R] for s in U if R in s]; sf=[s[R] for s in F if R in s]
    au=[s.get(R,0) for s in U]; af=[s.get(R,0) for s in F]
    print(R,'survivors',len(su),st.median(su),len(sf),st.median(sf),'ratio',round(st.median(su)/st.median(sf),2),
          '| all seats',st.median(au),st.median(af),'ratio',round(st.median(au)/st.median(af),2) if st.median(af) else 'inf')
    # cohort: seats alive at R15 in both, compare their R12
