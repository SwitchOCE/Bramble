"""Paper typical-line board size by round (B), from a scratch copy of qm3. python3 -I ck_paper_board.py"""
import importlib.util
from pathlib import Path
here = Path(__file__).parent / 'model'
spec = importlib.util.spec_from_file_location('p', here / 'presets3.py'); p = importlib.util.module_from_spec(spec); spec.loader.exec_module(p)
q = p.q
o, log = q.run('typical', q.Dials(**{**p.P['B'], 'cycle_cost': 6.0}), verbose=True)
for r, oo, bb in log:
    if r <= 8:
        print(r, oo['board'], len(bb), sum(1 for n, a, h in bb if n.startswith('flex')), [n for n, a, h in bb])
