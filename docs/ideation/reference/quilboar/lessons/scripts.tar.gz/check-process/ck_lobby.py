"""Survival, all-seat medians, same cohort growth, early board fill, game length, jumps. Committed compact archives. python3 -I ck_lobby.py"""
import gzip, json, glob, statistics as st, collections
EV='/home/alex/code/Bramble-ideation-sol/tools/sim/evidence'
ARMS={'B':EV+'/quilboar-h1-cycle-fix/B','uncut':EV+'/quilboar-h1-cycle-fix/uncut','C':EV+'/quilboar-h1/C','frozen':EV+'/quilboar-h1/uncut_frozen'}
def lobbies(arm):
    for f in sorted(glob.glob(ARMS[arm]+'/*.lobbies.json.gz')):
        for g in json.load(gzip.open(f)): yield g
for arm in ARMS:
    seats=collections.defaultdict(list); last=[]
    for g in lobbies(arm):
        mx=max(r['round'] for r in g['rounds']); last.append(mx)
        for p in g['players']:
            rs={r['round']:r for r in g['rounds'] if r['seat']==p['seat']}
            seats[p['line']].append(dict(rs=rs,place=p['place']))
    print('==',arm,'lobbies',len(last),'last round min/median/max',min(last),st.median(last),max(last),'ended by R14',sum(1 for x in last if x<=14))
    for line in ('line_quilboar_engine','line_birds_homecoming','line_fairies_ring','line_bog_engine','line_hedgerow_engine','line_hunters_engine','line_oozes_engine','hard'):
        ss=seats[line]; n=len(ss)
        a15=[s for s in ss if 15 in s['rs']]
        allm=st.median([s['rs'][15]['stats'] if 15 in s['rs'] else 0 for s in ss])
        surv=st.median([s['rs'][15]['stats'] for s in a15]) if a15 else None
        coh=[s for s in a15 if 12 in s['rs']]
        c12=st.median([s['rs'][12]['stats'] for s in coh]) if coh else None; c15=st.median([s['rs'][15]['stats'] for s in coh]) if coh else None
        u4=[len(s['rs'][4]['units']) for s in ss if 4 in s['rs']]; u6=[len(s['rs'][6]['units']) for s in ss if 6 in s['rs']]
        a4=[sum(1 for u in s['rs'][4]['units'] if u.get('active',True)) for s in ss if 4 in s['rs']]
        r6=st.median([s['rs'][6]['stats'] for s in ss if 6 in s['rs']])
        print(f"  {line:22s} n{n} alive15 {len(a15)/n:.3f} allseat15 {allm} surv15 {surv} cohort12 {c12} cohort15 {c15} g/round {((c15/c12)**(1/3)) if c12 else 0:.3f} units R4 {st.mean(u4):.2f} (active {st.mean(a4):.2f}) R6 {st.mean(u6):.2f} medR6 {r6}")
    q=seats['line_quilboar_engine']
    off=[round(st.mean([sum(1 for u in s['rs'][R]['units'] if not u['id'].startswith('qb_')) for s in q if R in s['rs']]),2) for R in range(3,9)]
    print('  quilboar off-tribe mean R3-R8',off)
    meds=[st.median([s['rs'][R]['stats'] for s in q if R in s['rs']]) for R in range(8,17)]
    print('  quilboar medians R8-16',meds,'jumps',[round(meds[i+1]/meds[i],2) for i in range(len(meds)-1)])
