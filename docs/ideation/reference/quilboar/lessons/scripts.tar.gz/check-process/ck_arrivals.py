"""Independent recount of Quilboar arrivals and conditional medians from committed compact archives.
python3 -I ck_arrivals.py"""
import gzip, json, glob, statistics as st
EV='/home/alex/code/Bramble-ideation-sol/tools/sim/evidence'
ARMS={'B_post':EV+'/quilboar-h1-cycle-fix/B','uncut_post':EV+'/quilboar-h1-cycle-fix/uncut',
      'C_pre':EV+'/quilboar-h1/C','uncut_pre':EV+'/quilboar-h1/uncut','frozen_pre':EV+'/quilboar-h1/uncut_frozen','B_pre':EV+'/quilboar-h1/B'}
PIECES={'qb_gem_rat':5,'qb_bramble_tunneler':7,'qb_sanguine_refiner':9,'qb_turbo_hogrider':11}
PAPER={'B_post':{9:167,12:1144,15:3363},'uncut_post':{9:222,12:6195,15:23945},'C_pre':{9:203,12:1942,15:6123}}
def seats(arm):
    out=[]
    for f in sorted(glob.glob(ARMS[arm]+'/*.lobbies.json.gz')):
        for g in json.load(gzip.open(f)):
            for p in g['players']:
                if p['line']!='line_quilboar_engine': continue
                rs={r['round']:r for r in g['rounds'] if r['seat']==p['seat']}
                ks=[r.get('keystone_found_round') for r in rs.values() if r.get('keystone_found_round')]
                out.append(dict(seed=g['seed'],place=p['place'],last=p['rounds'],rs=rs,ks=min(ks) if ks else None))
    return out
def first(s,uid):
    for r in sorted(s['rs']):
        if any(u['id']==uid for u in s['rs'][r]['units']): return r
def ftier(s,t):
    for r in sorted(s['rs']):
        if s['rs'][r]['tier']>=t: return r
res={}
for arm in ARMS:
    ss=seats(arm); n=len(ss); o={'n':n}
    for uid,pr in PIECES.items():
        fr=[first(s,uid) for s in ss]
        alive=[s for s in ss if pr in s['rs']]
        o[uid]=dict(on_time=round(sum(1 for x in fr if x and x<=pr)/n,4), never=round(sum(1 for x in fr if x is None)/n,4),
                    never_among_alive_at_R15=round(sum(1 for s in ss if 15 in s['rs'] and first(s,uid) is None)/max(1,sum(1 for s in ss if 15 in s['rs'])),4),
                    on_time_among_alive_at_paper_round=round(sum(1 for s in alive if (first(s,uid) or 99)<=pr)/len(alive),4))
    for t,pr in ((5,9),(6,11)):
        o['tier%d_on_time'%t]=round(sum(1 for s in ss if (ftier(s,t) or 99)<=pr)/n,4)
    allon=[s for s in ss if all((first(s,u) or 99)<=pr for u,pr in PIECES.items()) and (ftier(s,6) or 99)<=11]
    o['all_on_time']=(len(allon),round(len(allon)/n,4))
    # keystone field vs on-board detection
    o['hog_by_r12_onboard']=round(sum(1 for s in ss if (first(s,'qb_turbo_hogrider') or 99)<=12)/n,4)
    o['keystone_field_by_r12']=round(sum(1 for s in ss if s['ks'] and s['ks']<=12)/n,4)
    cond={}
    for r in (12,15):
        al=[s for s in ss if r in s['rs']]
        sel=[s['rs'][r]['stats'] for s in al if (first(s,'qb_turbo_hogrider') or 99)<=11 and (ftier(s,6) or 99)<=11]
        cond[r]=(len(sel), st.median(sel) if sel else None, round(st.median(sel)/PAPER[arm][r],3) if sel and arm in PAPER else None, len(al), st.median([s['rs'][r]['stats'] for s in al]))
    o['hog_t6_by_r11_cond']=cond
    h=[s['place'] for s in ss if (first(s,'qb_turbo_hogrider') or 99)<=12]; nh=[s['place'] for s in ss if (first(s,'qb_turbo_hogrider') or 99)>12]
    hk=[s['place'] for s in ss if s['ks'] and s['ks']<=12]; nk=[s['place'] for s in ss if not(s['ks'] and s['ks']<=12)]
    o['place_hog_onboard_r12']=(len(h),round(st.mean(h),3),round(sum(1 for p in h if p==1)/len(h),3),len(nh),round(st.mean(nh),3),round(sum(1 for p in nh if p==1)/len(nh),3))
    o['place_keystone_field_r12']=(len(hk),round(st.mean(hk),3),round(sum(1 for p in hk if p==1)/len(hk),3),len(nk),round(st.mean(nk),3),round(sum(1 for p in nk if p==1)/len(nk),3))
    gem={}
    for r in (9,12,15):
        al=[s for s in ss if r in s['rs']]
        gem[r]=st.median([s['rs'][r]['gem_size'][0] for s in al])
    o['gem_attack_median']=gem
    q7={}
    for r in (12,15):
        al=[s for s in ss if r in s['rs']]
        q7[r]=st.median([sum(1 for u in s['rs'][r]['units'] if u['id'].startswith('qb_')) for s in al])
    o['qb_units_median']=q7
    res[arm]=o
for a,o in res.items(): print(a, json.dumps(o))
