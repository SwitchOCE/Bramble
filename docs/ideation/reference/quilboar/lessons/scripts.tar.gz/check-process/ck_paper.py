"""Paper sensitivity checks on a scratch copy of qm3/presets3. python3 -I ck_paper.py"""
import importlib.util, math
from pathlib import Path
here = Path(__file__).parent / 'model'
spec = importlib.util.spec_from_file_location('p', here / 'presets3.py'); p = importlib.util.module_from_spec(spec); spec.loader.exec_module(p)
q = p.q
P = {k: {**v, 'cycle_cost': 6.0} for k, v in p.P.items()}
def run(line, kw, **x): return q.run(line, q.Dials(**{**kw, **x}))
for nm in ('B', 'uncut', 'C'):
    full = run('typical', P[nm]); nc = run('typical', P[nm], cycle_cost=999)
    print(nm, 'typical R12', full[12]['board'], 'no cycling', nc[12]['board'], 'ratio', round(nc[12]['board']/full[12]['board'],3),
          'cycles R8-16', [full[r]['cycles'] for r in range(8,17)])
    curve = {r: full[r]['board'] for r in range(5, 17)}
    print('   curve', curve)
# T6 cost 13
q.UPCOST[6] = 13
for nm in ('B', 'uncut'):
    o = run('typical', P[nm]); print(nm, 'T6=13 R12', o[12]['board'], 'R15', o[15]['board'])
