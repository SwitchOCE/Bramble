"""Lobby length (the winner's last round) and who wins, per arm, from the committed compact archives.
Usage: python3 -I game_length.py"""
import gzip, json, glob, statistics as st, collections
EV = '/home/alex/code/Bramble-ideation-sol/tools/sim/evidence'
ARMS = {'B_post': f'{EV}/quilboar-h1-cycle-fix/B', 'uncut_post': f'{EV}/quilboar-h1-cycle-fix/uncut',
        'C_pre': f'{EV}/quilboar-h1/C', 'frozen_pre': f'{EV}/quilboar-h1/uncut_frozen'}
for arm, d in ARMS.items():
    lengths = []; winners = collections.Counter(); qb_out = []
    for f in sorted(glob.glob(d + '/*.lobbies.json.gz')):
        for lob in json.load(gzip.open(f)):
            w = [p for p in lob['players'] if p['place'] == 1][0]
            lengths.append(w['rounds']); winners[w['line']] += 1
            q = [p for p in lob['players'] if p['line'] == 'line_quilboar_engine'][0]
            if q['place'] != 1: qb_out.append(q['rounds'])
    n = len(lengths)
    print(f'{arm:11s} n {n} lobby length median {st.median(lengths)} p25 {sorted(lengths)[n//4]} p75 {sorted(lengths)[3*n//4]}; share ending by R14 {sum(1 for x in lengths if x <= 14)/n:.2f}; Quilboar out (non-winner) median round {st.median(qb_out)}')
    print('    winners', dict(winners.most_common()))
