"""Arrival timing, board shape and gem size of the Quilboar seat in the committed H1 archives.
Reads only committed compact archives (lobbies.json.gz). Usage: python3 -I arrivals.py
"""
import gzip, json, glob, statistics as st, collections, sys
EV = '/home/alex/code/Bramble-ideation-sol/tools/sim/evidence'
ARMS = {
    'B_post': f'{EV}/quilboar-h1-cycle-fix/B',
    'uncut_post': f'{EV}/quilboar-h1-cycle-fix/uncut',
    'C_pre': f'{EV}/quilboar-h1/C',
    'uncut_pre': f'{EV}/quilboar-h1/uncut',
    'frozen_pre': f'{EV}/quilboar-h1/uncut_frozen',
    'B_pre': f'{EV}/quilboar-h1/B',
}
PAPER = {  # typical line arrivals, qm3.py LINES['typical']
    'qb_gem_rat': 5, 'qb_bramble_tunneler': 7, 'qb_sanguine_refiner': 9, 'qb_turbo_hogrider': 11,
}
PAPER_TIER = {5: 9, 6: 11}
PAPER_B = {6: 54, 9: 167, 12: 1144, 15: 3363}
PAPER_C = {6: 54, 9: 203, 12: 1942, 15: 6123}
PAPER_U = {6: 54, 9: 222, 12: 6195, 15: 23945}
PAPER_GEM_B = {9: 3, 12: 8, 15: 15}   # attack side, rounded (quilboar-port.md 10.2)
PAPER_GEM_C = {9: 5, 12: 15, 15: 29}

def load(arm):
    seats = []
    for f in sorted(glob.glob(ARMS[arm] + '/*.lobbies.json.gz')):
        for lob in json.load(gzip.open(f)):
            q = [p['seat'] for p in lob['roster'] if p['line'] == 'line_quilboar_engine']
            for s in q:
                rs = {r['round']: r for r in lob['rounds'] if r['seat'] == s}
                place = [p['place'] for p in lob['players'] if p['seat'] == s][0]
                seats.append({'seed': lob['seed'], 'rounds': rs, 'place': place})
    return seats

def first(rs, uid):
    for r in sorted(rs):
        if any(u['id'] == uid for u in rs[r]['units']):
            return r
    return None

def first_tier(rs, t):
    for r in sorted(rs):
        if rs[r]['tier'] >= t:
            return r
    return None

def med(xs):
    xs = [x for x in xs if x is not None]
    return st.median(xs) if xs else None

def share(xs, pred):
    return sum(1 for x in xs if pred(x)) / len(xs) if xs else None

out = {}
for arm in ARMS:
    seats = load(arm)
    n = len(seats)
    o = {'n': n}
    for uid, pr in PAPER.items():
        fr = [first(s['rounds'], uid) for s in seats]
        o[uid] = {'paper_round': pr, 'median_first_round_found_only': med(fr),
                  'share_on_time': share(fr, lambda x: x is not None and x <= pr),
                  'share_never': share(fr, lambda x: x is None)}
    for t, pr in PAPER_TIER.items():
        fr = [first_tier(s['rounds'], t) for s in seats]
        o[f'tier{t}'] = {'paper_round': pr, 'median_round': med(fr), 'share_on_time': share(fr, lambda x: x is not None and x <= pr)}
    # all four pieces and T6 on time
    def all_on_time(s):
        return all((first(s['rounds'], u) or 99) <= pr for u, pr in PAPER.items()) and (first_tier(s['rounds'], 6) or 99) <= 11
    o['all_on_time'] = share(seats, all_on_time)
    o['hog_and_t6_on_time'] = share(seats, lambda s: (first(s['rounds'], 'qb_turbo_hogrider') or 99) <= 11 and (first_tier(s['rounds'], 6) or 99) <= 11)
    # board shape
    shape = {}
    for r in (4, 6, 9, 12, 15):
        alive = [s for s in seats if r in s['rounds']]
        units = [len(s['rounds'][r]['units']) for s in alive]
        quil = [sum(1 for u in s['rounds'][r]['units'] if u['id'].startswith('qb_')) for s in alive]
        gem = [s['rounds'][r]['gem_size'] for s in alive]
        stats = [s['rounds'][r]['stats'] for s in alive]
        shape[r] = {'alive_share': len(alive) / n, 'median_units': med(units), 'median_qb_units': med(quil),
                    'median_gem_attack_halves': med([g[0] for g in gem]), 'median_stats': med(stats)}
    o['shape'] = shape
    # conditional accounting: Hogrider by R11 vs not, at R12 and R15
    cond = {}
    for r in (12, 15):
        alive = [s for s in seats if r in s['rounds']]
        on = [s['rounds'][r]['stats'] for s in alive if (first(s['rounds'], 'qb_turbo_hogrider') or 99) <= 11]
        ont6 = [s['rounds'][r]['stats'] for s in alive if (first(s['rounds'], 'qb_turbo_hogrider') or 99) <= 11 and (first_tier(s['rounds'], 6) or 99) <= 11]
        allon = [s['rounds'][r]['stats'] for s in alive if all_on_time(s)]
        late = [s['rounds'][r]['stats'] for s in alive if (first(s['rounds'], 'qb_turbo_hogrider') or 99) > 11]
        cond[r] = {'hog_by_r11': (len(on), med(on)), 'hog_and_t6_by_r11': (len(ont6), med(ont6)),
                   'all_four_and_t6_on_time': (len(allon), med(allon)), 'hog_after_r11_or_never': (len(late), med(late))}
    o['conditional'] = cond
    # placement by Hogrider at R12
    hog12 = [s['place'] for s in seats if (first(s['rounds'], 'qb_turbo_hogrider') or 99) <= 12]
    nohog12 = [s['place'] for s in seats if (first(s['rounds'], 'qb_turbo_hogrider') or 99) > 12]
    o['place'] = {'hog_by_r12': (len(hog12), st.mean(hog12) if hog12 else None, share(hog12, lambda p: p == 1)),
                  'no_hog_by_r12': (len(nohog12), st.mean(nohog12) if nohog12 else None, share(nohog12, lambda p: p == 1))}
    out[arm] = o

json.dump(out, open(sys.argv[1] if len(sys.argv) > 1 else '/dev/stdout', 'w'), indent=1, default=str)
