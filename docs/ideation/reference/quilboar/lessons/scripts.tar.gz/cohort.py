import os, sys, statistics
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from qload import ARMS, load, med, seats_of, surv_median, growth
print("| Arm | Window | survivor-median lobby growth | same-cohort (alive at end) per-seat median | cohort n | median growth if eliminated seats are ranked lowest (ITT) |")
for arm in ["B", "C", "uncut", "uncut_frozen"]:
    L = load(arm)
    for a, b in [(8, 14), (9, 15), (10, 16), (8, 12), (12, 15)]:
        sm = growth(surv_median(L, a), surv_median(L, b), b - a)
        coh = [s for s in seats_of(L) if b in s["board"] and s["board"].get(a, 0) > 0]
        cg = med([(s["board"][b] / s["board"][a]) ** (1 / (b - a)) for s in coh])
        allv_a = [s["board"].get(a, 0) for s in seats_of(L)]
        allv_b = [s["board"].get(b, 0) for s in seats_of(L)]
        ia, ib = med(allv_a), med(allv_b)
        ig = growth(ia, ib, b - a)
        print(f"| {arm} | R{a}-R{b} | {sm:.3f} | {cg:.3f} | {len(coh)} | {ig if ig is None else round(ig,3)} (ITT R{b} median {ib}) |")
