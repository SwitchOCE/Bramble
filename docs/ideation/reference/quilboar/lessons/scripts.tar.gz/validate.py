import sys
sys.path.insert(0, '/tmp/claude-1000/-home-alex-code-Bramble-ideation/94bf7aaf-6a89-4561-b3da-52d1971d0dd7/scratchpad/quilboar-lessons')
from qload import *
for arm in ARMS:
    L = load(arm)
    q12 = surv_median(L, 12, 'line_quilboar_engine')
    b12 = surv_median(L, 12, 'line_birds_homecoming')
    g = growth(surv_median(L, 8), surv_median(L, 14), 6)
    print(arm, len(L), 'Q R12', q12, 'Birds R12', b12, 'lobby growth', round(g, 4))
