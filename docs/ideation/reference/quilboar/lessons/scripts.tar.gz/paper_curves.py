"""Paper typical-line curves (board, gem size) R5-R16 for B, C, uncut, from a scratch copy of the
committed model (docs/ideation/reference/quilboar/model on ideation/quilboar). Also the T6=13 variant.
Usage: python3 paper_curves.py out.json"""
import importlib.util, json, sys
from pathlib import Path
here = Path(__file__).parent / 'model'
spec = importlib.util.spec_from_file_location('p', here / 'presets3.py')
p = importlib.util.module_from_spec(spec); spec.loader.exec_module(p)
q = p.q
CYC = 6.0
out = {}
for t6 in (11, 13):
    q.UPCOST[6] = t6
    for nm in ('B', 'C', 'uncut'):
        kw = {**p.P[nm], 'cycle_cost': CYC}
        for line in ('typical', 'low_roll'):
            o = q.run(line, q.Dials(**kw))
            out[f'{nm}_{line}_t6_{t6}'] = {r: {'board': o[r]['board'], 'S': o[r]['S']} for r in range(5, 17)}
q.UPCOST[6] = 11
json.dump(out, open(sys.argv[1], 'w'), indent=1, default=str)
for k in ('B_typical_t6_11', 'uncut_typical_t6_11', 'C_typical_t6_11', 'B_low_roll_t6_11'):
    print(k, [out[k][r]['board'] for r in range(5, 17)])
    print('   S', [out[k][r]['S'] for r in (9, 12, 15)])
