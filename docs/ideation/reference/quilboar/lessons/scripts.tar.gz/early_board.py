"""Early board fill: Quilboar seat against the Hard seat and the native lines, R3-R8, B post-fix
and uncut post-fix (committed compact archives). Also the off-tribe (flex) count on Quilboar boards.
Usage: python3 -I early_board.py"""
import gzip, json, glob, statistics as st, collections
EV = '/home/alex/code/Bramble-ideation-sol/tools/sim/evidence/quilboar-h1-cycle-fix'
for arm in ('B', 'uncut'):
    units = collections.defaultdict(lambda: collections.defaultdict(list))
    stats = collections.defaultdict(lambda: collections.defaultdict(list))
    flex = collections.defaultdict(list)
    for f in sorted(glob.glob(f'{EV}/{arm}/*.lobbies.json.gz')):
        for lob in json.load(gzip.open(f)):
            for r in lob['rounds']:
                if 3 <= r['round'] <= 8:
                    units[r['line']][r['round']].append(len(r['units']))
                    stats[r['line']][r['round']].append(r['stats'])
                    if r['line'] == 'line_quilboar_engine':
                        flex[r['round']].append(sum(1 for u in r['units'] if not u['id'].startswith('qb_')))
    print('==', arm)
    for line in ('line_quilboar_engine', 'hard', 'line_birds_homecoming', 'line_bog_engine'):
        print(f'  {line:22s} mean units R3-R8', [round(st.mean(units[line][r]), 2) for r in range(3, 9)],
              ' median stats', [st.median(stats[line][r]) for r in range(3, 9)])
    print('  quilboar off-tribe units R3-R8 mean', [round(st.mean(flex[r]), 2) for r in range(3, 9)])
