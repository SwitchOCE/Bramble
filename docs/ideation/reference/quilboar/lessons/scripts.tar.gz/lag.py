"""How many rounds late the real median is against the paper typical curve (log interpolation),
and what an accounting band of 0.5-2x tolerates in rounds at each read round.
Inputs: paper_curves.json (paper_curves.py), arrivals.json (arrivals.py). Usage: python3 -I lag.py"""
import json, math
P = json.load(open('paper_curves.json')); A = json.load(open('arrivals.json'))
def curve(k): return {int(r): v['board'] for r, v in P[k].items()}
def paper_round_for(c, x):
    rs = sorted(c)
    for a, b in zip(rs, rs[1:]):
        if c[a] <= x <= c[b]:
            return a + (math.log(x) - math.log(c[a])) / (math.log(c[b]) - math.log(c[a]))
    return None
def tol(c, r):
    lo = paper_round_for(c, 0.5 * c[r]); hi = paper_round_for(c, 2 * c[r])
    return (round(r - lo, 2) if lo else None, round(hi - r, 2) if hi else None)
for arm, key in (('B_post', 'B_typical_t6_11'), ('C_pre', 'C_typical_t6_11'), ('uncut_post', 'uncut_typical_t6_11'), ('uncut_pre', 'uncut_typical_t6_11')):
    c = curve(key)
    print('==', arm)
    for r in (6, 9, 12, 15):
        real = A[arm]['shape'][str(r)]['median_stats']
        pr = paper_round_for(c, real)
        print(f'  R{r}: real {real}  paper {c[r]}  ratio {real/c[r]:.3f}  real equals paper at R{pr:.2f} -> {r-pr:.2f} rounds late' if pr else f'  R{r}: real {real} paper {c[r]} below R5')
        print(f'        band 0.5-2x tolerates {tol(c, r)[0]} rounds late, {tol(c, r)[1]} rounds early; paper growth into R{r}: x{c[r]/c[r-1]:.2f}')
