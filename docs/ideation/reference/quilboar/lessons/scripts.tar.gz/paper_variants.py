"""Paper B/uncut typical line with Phase 1's missing Roadboar, and with arrivals shifted one round late
(each scripted buy and climb one round later), from a scratch copy of the committed model.
Usage: python3 paper_variants.py"""
import importlib.util, copy
from pathlib import Path
here = Path(__file__).parent / 'model'
spec = importlib.util.spec_from_file_location('p', here / 'presets3.py')
p = importlib.util.module_from_spec(spec); spec.loader.exec_module(p)
q = p.q
orig = copy.deepcopy(q.LINES['typical'])
def run(nm, L):
    q.LINES['typical'] = L
    o = q.run('typical', q.Dials(**{**p.P[nm], 'cycle_cost': 6.0}))
    q.LINES['typical'] = copy.deepcopy(orig)
    return [o[r]['board'] for r in (6, 9, 12, 15)]
for nm in ('B', 'uncut'):
    base = run(nm, copy.deepcopy(orig))
    L = copy.deepcopy(orig); L['buys'] = {r: [('flex3' if x == 'roadboar' else x) for x in xs] for r, xs in L['buys'].items()}
    noroad = run(nm, L)
    # one round late: every buy from R5 on and every climb from T4 on moves one round later
    L = copy.deepcopy(orig)
    L['buys'] = {(r + 1 if r >= 5 else r): xs for r, xs in orig['buys'].items()}
    for r in range(1, 17): L['buys'].setdefault(r, [])
    L['climb'] = {t: (r + 1 if t >= 4 else r) for t, r in orig['climb'].items()}
    L['golden'] = {r + 1: n for r, n in orig['golden'].items()}
    late1 = run(nm, L)
    # Hogrider only, one round late
    L = copy.deepcopy(orig); L['buys'][11] = [x for x in L['buys'][11] if x != 'hogrider']; L['buys'][12] = L['buys'][12] + ['hogrider']
    hog_late = run(nm, L)
    print(nm, 'base', base, '| Roadboar as a 4/4', noroad, '| all from R5 one round late', late1, '| Hogrider R12', hog_late)
    print('   ratios to base R12/R15:', 'noroad', round(noroad[2]/base[2], 2), round(noroad[3]/base[3], 2),
          'late1', round(late1[2]/base[2], 2), round(late1[3]/base[3], 2), 'hog R12', round(hog_late[2]/base[2], 2), round(hog_late[3]/base[3], 2))
