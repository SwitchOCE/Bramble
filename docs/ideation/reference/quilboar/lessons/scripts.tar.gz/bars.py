"""Test our yardsticks against the Quilboar H1 reference archives. Python only, read-only inputs.

Writes bars-out.json next to this script and prints the tables used in bars.md.
"""
import json
import math
import os
import statistics
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from qload import ARMS, LINES, SHORT, boot, growth, itt_median, load, med, seats_of, surv_median  # noqa: E402

OUT = {}
DATA = {arm: load(arm) for arm in ARMS}
CANON = ["B", "C", "uncut", "uncut_frozen"]
Q = "line_quilboar_engine"
R = range(6, 19)


def fmt(x, d=2):
    if x is None:
        return "-"
    if isinstance(x, float):
        return f"{x:.{d}f}"
    return str(x)


def ci(t):
    return f"[{fmt(t[0])}, {fmt(t[1])}]"


# ---------------------------------------------------------------- 1. growth per line
print("\n## 1. Per-line growth R8->R14")
OUT["growth"] = {}
for arm in CANON + ["B_pre", "uncut_pre"]:
    L = DATA[arm]
    OUT["growth"][arm] = {}
    rows = []
    for line in LINES:
        s8, s14 = surv_median(L, 8, line), surv_median(L, 14, line)
        sg = growth(s8, s14, 6)
        sg_ci = boot(L, lambda S, line=line: growth(surv_median(S, 8, line), surv_median(S, 14, line), 6), reps=1000)
        coh = [s for s in seats_of(L, line) if 14 in s["board"] and s["board"].get(8, 0) > 0]
        per_seat = [(s["board"][14] / s["board"][8]) ** (1 / 6) for s in coh]
        cg = med(per_seat)
        cg_ci = boot(L, lambda S, line=line: med([(s["board"][14] / s["board"][8]) ** (1 / 6)
                                                   for s in seats_of(S, line) if 14 in s["board"] and s["board"].get(8, 0) > 0]), reps=1000)
        n_all = sum(1 for _ in seats_of(L, line))
        i8, i14 = itt_median(L, 8, line), itt_median(L, 14, line)
        ig = growth(i8, i14, 6)
        share_ge_13 = sum(1 for g in per_seat if g >= 1.3) / len(per_seat) if per_seat else None
        OUT["growth"][arm][line] = {
            "surv_R8": s8, "surv_R14": s14, "surv_growth": sg, "surv_growth_ci": sg_ci,
            "cohort_n": len(coh), "seats": n_all, "cohort_growth_median_per_seat": cg, "cohort_growth_ci": cg_ci,
            "cohort_share_seats_ge_1.3": share_ge_13,
            "itt_R8": i8, "itt_R14": i14, "itt_growth": ig,
        }
        rows.append((SHORT[line], fmt(sg, 3), ci(sg_ci), fmt(cg, 3), ci(cg_ci), f"{len(coh)}/{n_all}",
                     fmt(share_ge_13, 2), fmt(ig, 3)))
    print(f"\n### {arm}")
    print("| Line | Survivor-median growth | 95% | Same-cohort per-seat median | 95% | Alive R14 / seats | Seats >=1.3 | ITT growth |")
    for r_ in rows:
        print("| " + " | ".join(r_) + " |")

# lobby-median growth, and whether one strong seat moves it
print("\n## 1b. Lobby-median growth (checkpoint criterion 2)")
OUT["lobby_growth"] = {}
print("| Arm | All 8 seats | 95% | Without Quilboar seat | Without Quilboar or Hard | Quilboar R14 survivor median | Survivors R8 / R14 | Lobby mean growth |")
for arm in CANON + ["B_pre", "uncut_pre"]:
    L = DATA[arm]
    g_all = growth(surv_median(L, 8), surv_median(L, 14), 6)
    g_ci = boot(L, lambda S: growth(surv_median(S, 8), surv_median(S, 14), 6))
    g_noq = growth(surv_median(L, 8, exclude=(Q,)), surv_median(L, 14, exclude=(Q,)), 6)
    g_noqh = growth(surv_median(L, 8, exclude=(Q, "hard")), surv_median(L, 14, exclude=(Q, "hard")), 6)
    n8 = sum(1 for s in seats_of(L) if 8 in s["board"])
    n14 = sum(1 for s in seats_of(L) if 14 in s["board"])
    mean8 = statistics.mean([s["board"][8] for s in seats_of(L) if 8 in s["board"]])
    mean14 = statistics.mean([s["board"][14] for s in seats_of(L) if 14 in s["board"]])
    g_mean = growth(mean8, mean14, 6)
    OUT["lobby_growth"][arm] = {"all": g_all, "ci": g_ci, "without_quilboar": g_noq, "without_quilboar_hard": g_noqh,
                                "survivors_R8": n8, "survivors_R14": n14, "mean_growth": g_mean,
                                "quilboar_R14": surv_median(L, 14, Q)}
    print(f"| {arm} | {fmt(g_all, 3)} | {ci(g_ci)} | {fmt(g_noq, 3)} | {fmt(g_noqh, 3)} | {surv_median(L, 14, Q)} | {n8}/{n14} | {fmt(g_mean, 3)} |")

# where the lobby median sits: which line is at the median seat at R14?
print("\n### Line mix of R14 survivors, and the median's neighbours")
for arm in CANON:
    L = DATA[arm]
    surv = sorted((s["board"][14], SHORT[s["line"]]) for s in seats_of(L) if 14 in s["board"])
    mid = len(surv) // 2
    window = surv[max(0, mid - 10): mid + 10]
    from collections import Counter
    mix = Counter(x[1] for x in surv)
    print(arm, "n", len(surv), "median", surv[mid][0], "window lines", dict(Counter(x[1] for x in window)), "mix", dict(mix))

# ---------------------------------------------------------------- 2. shape
print("\n## 2. Shape of growth")
OUT["shape"] = {}
for arm in CANON:
    L = DATA[arm]
    OUT["shape"][arm] = {}
    print(f"\n### {arm}: round-over-round ratio of survivor medians (R7..R17), alive count")
    print("| Line | " + " | ".join(f"R{r}" for r in range(8, 18)) + " | R13/R12 | R14/R12 | R15/R12 | log share after R12 (R8->R15) |")
    for line in LINES:
        meds = {r: surv_median(L, r, line) for r in range(7, 18)}
        ratios = []
        for r in range(8, 18):
            a, b = meds.get(r - 1), meds.get(r)
            ratios.append(b / a if a and b else None)
        m12, m13, m14, m15, m8 = meds[12], meds[13], meds[14], meds[15], meds[8]
        late = (math.log(m15 / m12) / math.log(m15 / m8)) if m15 and m12 and m8 and m15 > m8 else None
        OUT["shape"][arm][line] = {"medians": meds, "ratios": dict(zip(range(8, 18), ratios)),
                                   "r13_r12": m13 / m12 if m13 and m12 else None,
                                   "r14_r12": m14 / m12 if m14 and m12 else None,
                                   "r15_r12": m15 / m12 if m15 and m12 else None, "late_log_share": late}
        print(f"| {SHORT[line]} | " + " | ".join(fmt(x, 2) for x in ratios) +
              f" | {fmt(OUT['shape'][arm][line]['r13_r12'])} | {fmt(OUT['shape'][arm][line]['r14_r12'])} | {fmt(OUT['shape'][arm][line]['r15_r12'])} | {fmt(late)} |")

    # same cohort (alive at R15), per-seat ratios
    print(f"\n#### {arm}: same cohort alive at R15, median per-seat ratios and jump round")
    print("| Line | n alive R15 / seats | R12->R13 | R13->R14 | R14->R15 | R15/R12 | R12/R8 | jump round (median, IQR) | jump round mode | median biggest one-round ratio |")
    for line in LINES:
        coh = [s for s in seats_of(L, line) if 15 in s["board"] and all(r in s["board"] for r in range(7, 16)) and s["board"][7] > 0]
        nall = sum(1 for _ in seats_of(L, line))
        if not coh:
            print(f"| {SHORT[line]} | 0/{nall} |")
            continue
        def pr(a, b):
            return med([s["board"][b] / s["board"][a] for s in coh if s["board"][a] > 0])
        jumps, biggest = [], []
        for s in coh:
            best = max(range(8, 16), key=lambda r: s["board"][r] / max(1, s["board"][r - 1]))
            jumps.append(best)
            biggest.append(s["board"][best] / max(1, s["board"][best - 1]))
        jumps.sort()
        from collections import Counter
        mode = Counter(jumps).most_common(1)[0]
        q1, q3 = jumps[len(jumps) // 4], jumps[(3 * len(jumps)) // 4]
        OUT["shape"][arm][line]["cohort15"] = {"n": len(coh), "seats": nall, "r12_13": pr(12, 13), "r13_14": pr(13, 14),
                                               "r14_15": pr(14, 15), "r15_12": pr(12, 15), "r12_8": pr(8, 12),
                                               "jump_median": med(jumps), "jump_iqr": [q1, q3], "jump_mode": mode,
                                               "biggest_ratio_median": med(biggest)}
        print(f"| {SHORT[line]} | {len(coh)}/{nall} | {fmt(pr(12, 13))} | {fmt(pr(13, 14))} | {fmt(pr(14, 15))} | {fmt(pr(12, 15))} | {fmt(pr(8, 12))} | R{med(jumps)} (R{q1}-R{q3}) | R{mode[0]} ({mode[1]}) | {fmt(med(biggest))} |")

# rank at each read round, and survivor vs ITT medians late
print("\n### R12 vs R14 vs R15 ranking of Quilboar against the best native line, survivor and ITT medians")
OUT["rank"] = {}
print("| Arm | Round | Quilboar surv | best native surv (line) | ratio | Quilboar ITT | best native ITT (line) | ITT ratio | Quilboar alive share |")
for arm in CANON:
    L = DATA[arm]
    OUT["rank"][arm] = {}
    for r in (9, 12, 13, 14, 15, 16):
        q = surv_median(L, r, Q)
        nat = [(surv_median(L, r, ln), ln) for ln in LINES if ln not in (Q, "hard") and surv_median(L, r, ln) is not None]
        best = max(nat)
        qi = itt_median(L, r, Q)
        nat_i = [(itt_median(L, r, ln), ln) for ln in LINES if ln not in (Q, "hard")]
        best_i = max(nat_i)
        alive = sum(1 for s in seats_of(L, Q) if r in s["board"]) / sum(1 for _ in seats_of(L, Q))
        OUT["rank"][arm][r] = {"q": q, "best_native": best, "q_itt": qi, "best_native_itt": best_i, "q_alive": alive}
        print(f"| {arm} | R{r} | {q} | {best[0]} ({SHORT[best[1]]}) | {fmt(q / best[0] if q and best[0] else None)} | {qi} | {best_i[0]} ({SHORT[best_i[1]]}) | {fmt(qi / best_i[0] if qi and best_i[0] else None)} | {fmt(alive)} |")

# ---------------------------------------------------------------- 3. generosity against BG
print("\n## 3. Quilboar at C dials against uncut, and against BG")
OUT["generosity"] = {}
paper = {"B": {9: 167, 12: 1144, 15: 3363}, "C": {9: 203, 12: 1942, 15: 6123}, "uncut": {9: 222, 12: 6195, 15: 23945},
         "uncut_frozen": {9: 123, 12: 532, 15: 1190}}
bg = {"sep2025_mean": {12: 759, 14: 1751}, "nov2026_mean": {12: 3505, 14: 6850}, "nov2026_median": {12: 2598, 14: 7980},
      "nov2026_top04_median": {12: 7598, 14: 21440}}
for arm in ["B", "B_pre", "C", "uncut", "uncut_pre", "uncut_frozen"]:
    L = DATA[arm]
    OUT["generosity"][arm] = {r: {"surv": surv_median(L, r, Q), "post_start": med([s["post"][r] for s in seats_of(L, Q) if r in s["post"]]),
                                  "itt": itt_median(L, r, Q),
                                  "ci": boot(L, lambda S, r=r: surv_median(S, r, Q), reps=1000)} for r in (9, 12, 14, 15)}
    print(arm, {r: (v["surv"], v["post_start"], v["itt"], v["ci"]) for r, v in OUT["generosity"][arm].items()})
OUT["paper"] = paper
OUT["bg"] = bg

# ratio C/uncut with CI (unpaired: independent bootstrap of each arm)
import random
def ratio_ci(armA, armB, r, reps=2000, seed=7):
    rng = random.Random(seed)
    A, B = DATA[armA], DATA[armB]
    vals = []
    for _ in range(reps):
        sa = [A[rng.randrange(len(A))] for _ in A]
        sb = [B[rng.randrange(len(B))] for _ in B]
        a, b = surv_median(sa, r, Q), surv_median(sb, r, Q)
        if a and b:
            vals.append(a / b)
    vals.sort()
    return vals[int(0.025 * len(vals))], vals[int(0.975 * len(vals))]

OUT["ratios"] = {}
for (a, b) in [("C", "uncut_pre"), ("C", "uncut"), ("B_pre", "uncut_pre"), ("B", "uncut"), ("C", "B_pre"), ("uncut_frozen", "uncut_pre")]:
    for r in (12, 14, 15):
        pa, pb = surv_median(DATA[a], r, Q), surv_median(DATA[b], r, Q)
        c = ratio_ci(a, b, r)
        OUT["ratios"][f"{a}/{b}@R{r}"] = {"point": pa / pb, "ci": c}
        print(f"{a}/{b} R{r}: {pa}/{pb} = {pa / pb:.3f} {ci(c)}")

# ---------------------------------------------------------------- 4. key-card arrival
print("\n## 4. Key-card arrival")
OUT["arrival"] = {}

def first_on_board(s, cid):
    for r in sorted(s["units"]):
        if cid in s["units"][r]:
            return r
    return None

def first_tier(s, t):
    for r in sorted(s["tier"]):
        if s["tier"][r] >= t:
            return r
    return None

def place_stats(seats):
    if not seats:
        return {"n": 0}
    return {"n": len(seats), "mean_place": statistics.mean(s["place"] for s in seats),
            "first": sum(1 for s in seats if s["place"] == 1) / len(seats),
            "top4": sum(1 for s in seats if s["place"] <= 4) / len(seats),
            "R12": med([s["board"][12] for s in seats if 12 in s["board"]]),
            "R15": med([s["board"][15] for s in seats if 15 in s["board"]])}

for arm in CANON + ["B_pre", "uncut_pre"]:
    L = DATA[arm]
    qs = list(seats_of(L, Q))
    res = {}
    for name, fn in [("hogrider_inventory", lambda s: s["keystone"]),
                     ("hogrider_board", lambda s: first_on_board(s, "qb_turbo_hogrider")),
                     ("tunneler_board", lambda s: first_on_board(s, "qb_bramble_tunneler")),
                     ("gem_rat_board", lambda s: first_on_board(s, "qb_gem_rat")),
                     ("refiner_board", lambda s: first_on_board(s, "qb_sanguine_refiner")),
                     ("tier5", lambda s: first_tier(s, 5)), ("tier6", lambda s: first_tier(s, 6))]:
        vals = [fn(s) for s in qs]
        got = sorted(v for v in vals if v is not None)
        alive12 = [s for s in qs if 12 in s["board"]]
        by11 = sum(1 for s in qs if fn(s) is not None and fn(s) <= 11) / len(qs)
        by12 = sum(1 for s in qs if fn(s) is not None and fn(s) <= 12) / len(qs)
        by12_alive = sum(1 for s in alive12 if fn(s) is not None and fn(s) <= 12) / len(alive12)
        res[name] = {"n_seats": len(qs), "ever": len(got) / len(qs), "median_round_if_found": med(got),
                     "q1": got[len(got) // 4] if got else None, "q3": got[(3 * len(got)) // 4] if got else None,
                     "by_R11_all": by11, "by_R12_all": by12, "by_R12_alive12": by12_alive}
    # placement by Hogrider (inventory) arrival bucket, among seats alive at R12
    alive12 = [s for s in qs if 12 in s["board"]]
    buckets = {"<=R11": [], "R12": [], ">=R13": [], "never": []}
    for s in alive12:
        k = s["keystone"]
        if k is None:
            buckets["never"].append(s)
        elif k <= 11:
            buckets["<=R11"].append(s)
        elif k == 12:
            buckets["R12"].append(s)
        else:
            buckets[">=R13"].append(s)
    res["by_hogrider_bucket_alive12"] = {b: place_stats(v) for b, v in buckets.items()}
    # with/without by R12 among alive at R12
    w = [s for s in alive12 if s["keystone"] is not None and s["keystone"] <= 12]
    wo = [s for s in alive12 if not (s["keystone"] is not None and s["keystone"] <= 12)]
    res["with_by12_alive12"] = place_stats(w)
    res["without_by12_alive12"] = place_stats(wo)
    res["all_seats"] = place_stats(qs)
    res["died_before_R12"] = place_stats([s for s in qs if 12 not in s["board"]])
    # Tunneler on board by R9 (paper: R7) split
    alive9 = [s for s in qs if 9 in s["board"]]
    t_w = [s for s in alive9 if (first_on_board(s, "qb_bramble_tunneler") or 99) <= 9]
    t_wo = [s for s in alive9 if (first_on_board(s, "qb_bramble_tunneler") or 99) > 9]
    res["tunneler_by9_alive9"] = place_stats(t_w)
    res["no_tunneler_by9_alive9"] = place_stats(t_wo)
    OUT["arrival"][arm] = res
    print(f"\n### {arm}")
    for k, v in res.items():
        print(" ", k, {kk: (round(vv, 3) if isinstance(vv, float) else vv) for kk, vv in v.items()} if isinstance(v, dict) and "n" not in v else v)

# native engine pieces
print("\n### Native lines: engine pieces on board")
PIECES = {
    "line_birds_homecoming": ["mrs_stork", "mr_redbreast", "great_lump", "cuckoo", "mother_goose"],
    "line_fairies_ring": ["old_moth_annis", "cluricaun", "cradle_fetch", "fairy_monarch", "queen_of_elfland"],
    "line_bog_engine": ["jenny_greenteeth", "vaulting_hopkin", "peat_king"],
    "line_hedgerow_engine": ["alderman_dozey", "honorary_treasurer", "squire_lollop"],
    "line_hunters_engine": ["brother_wolf", "grizel"],
    "line_oozes_engine": ["mr_syllabub", "elder_ooze"],
}
OUT["native_pieces"] = {}
for arm in ["B", "uncut"]:
    L = DATA[arm]
    OUT["native_pieces"][arm] = {}
    print(f"\n#### {arm}")
    print("| Line | Piece | on board by R12 (alive R12) | median first round | place with / without (alive R12) | first-rate with / without | R12 board with / without |")
    for line, pcs in PIECES.items():
        seats = [s for s in seats_of(L, line) if 12 in s["board"]]
        OUT["native_pieces"][arm][line] = {}
        for p in pcs:
            fr = [first_on_board(s, p) for s in seats]
            w = [s for s, f in zip(seats, fr) if f is not None and f <= 12]
            wo = [s for s, f in zip(seats, fr) if not (f is not None and f <= 12)]
            got = sorted(f for f in fr if f is not None and f <= 12)
            pw, pwo = place_stats(w), place_stats(wo)
            OUT["native_pieces"][arm][line][p] = {"share_by12": len(w) / len(seats), "median_first": med(got), "with": pw, "without": pwo}
            print(f"| {SHORT[line]} | {p} | {len(w) / len(seats):.2f} | {med(got)} | {fmt(pw.get('mean_place'))} / {fmt(pwo.get('mean_place'))} | {fmt(pw.get('first'))} / {fmt(pwo.get('first'))} | {pw.get('R12')} / {pwo.get('R12')} |")

# ---------------------------------------------------------------- 5. criteria
print("\n## 5. Criteria")
OUT["criteria"] = {}
for arm in CANON + ["B_pre", "uncut_pre"]:
    L = DATA[arm]
    rows = {}
    for line in LINES:
        ss = list(seats_of(L, line))
        first = sum(1 for s in ss if s["place"] == 1) / len(ss)
        fci = boot(L, lambda S, line=line: (lambda xs: sum(1 for s in xs if s["place"] == 1) / len(xs))(list(seats_of(S, line))))
        mp = statistics.mean(s["place"] for s in ss)
        # paired in-lobby gap to the Hard anchor (proxy for the line-strength gate)
        def gap(S, line=line):
            d = []
            for lob in S:
                lp = [s["place"] for s in lob["seats"] if s["line"] == line][0]
                hp = [s["place"] for s in lob["seats"] if s["line"] == "hard"][0]
                d.append(hp - lp)
            return statistics.mean(d)
        g = gap(L)
        gci = boot(L, gap)
        rows[line] = {"first": first, "first_ci": fci, "mean_place": mp, "gain_vs_hard": g, "gain_ci": gci,
                      "top4": sum(1 for s in ss if s["place"] <= 4) / len(ss)}
    inside = [ln for ln, v in rows.items() if 0.06 <= v["first"] <= 0.25]
    above = [ln for ln, v in rows.items() if v["first"] > 0.25]
    lg = OUT["lobby_growth"][arm]["all"]
    OUT["criteria"][arm] = {"lines": rows, "depth_inside": inside, "depth_above": above,
                            "depth_pass": len(inside) >= 5 and not above, "lobby_growth": lg, "lobby_growth_pass": lg >= 1.3}
    print(f"\n### {arm}: depth inside={len(inside)} {[SHORT[x] for x in inside]} above={[SHORT[x] for x in above]} lobby growth {lg:.3f}")
    print("| Line | First rate | 95% | Mean place | Top-4 | Place gain vs Hard (in-lobby, paired) | 95% | Gate proxy |")
    for ln, v in rows.items():
        gate = "pass" if v["gain_ci"][0] > 0 else ("fail (worse)" if v["gain_ci"][1] < 0 else "fail (not shown)")
        if ln == "hard":
            gate = "-"
        print(f"| {SHORT[ln]} | {v['first']:.3f} | {ci(v['first_ci'])} | {v['mean_place']:.2f} | {v['top4']:.2f} | {v['gain_vs_hard']:+.2f} | {ci(v['gain_ci'])} | {gate} |")

# order-of-magnitude extreme miss
print("\n### Order-of-magnitude extreme miss: best line / worst line survivor median")
OUT["oom"] = {}
for arm in CANON:
    L = DATA[arm]
    OUT["oom"][arm] = {}
    for r in (12, 14, 15):
        meds = {ln: surv_median(L, r, ln) for ln in LINES if ln != "hard"}
        hi = max(meds.items(), key=lambda kv: kv[1])
        lo = min(meds.items(), key=lambda kv: kv[1])
        nat = {k: v for k, v in meds.items() if k != Q}
        hi_n = max(nat.items(), key=lambda kv: kv[1])
        lo_n = min(nat.items(), key=lambda kv: kv[1])
        OUT["oom"][arm][r] = {"hi": hi, "lo": lo, "ratio": hi[1] / lo[1], "native_ratio": hi_n[1] / lo_n[1]}
        print(f"{arm} R{r}: {SHORT[hi[0]]} {hi[1]} / {SHORT[lo[0]]} {lo[1]} = {hi[1] / lo[1]:.1f}x; natives only {SHORT[hi_n[0]]}/{SHORT[lo_n[0]]} = {hi_n[1] / lo_n[1]:.1f}x")

# R8 leader win rate check (descriptive, from summary)
with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "bars-out.json"), "w") as f:
    json.dump(OUT, f, indent=1, default=str)
print("\nwrote bars-out.json")
