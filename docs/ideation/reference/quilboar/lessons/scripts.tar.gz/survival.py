"""Share of seats alive (observed pre-start board) at R12 and R15 per line, and the Quilboar R13/R15
medians over all seats with eliminated seats counted as 0 (a survivor-free reading). B post-fix.
Usage: python3 -I survival.py"""
import gzip, json, glob, statistics as st, collections
EV = '/home/alex/code/Bramble-ideation-sol/tools/sim/evidence/quilboar-h1-cycle-fix'
for arm in ('B', 'uncut'):
    alive = collections.defaultdict(lambda: collections.Counter()); seats = collections.Counter()
    allseat = collections.defaultdict(lambda: collections.defaultdict(list))
    for f in sorted(glob.glob(f'{EV}/{arm}/*.lobbies.json.gz')):
        for lob in json.load(gzip.open(f)):
            for p in lob['roster']:
                seats[p['line']] += 1
                rs = {r['round']: r['stats'] for r in lob['rounds'] if r['seat'] == p['seat']}
                for R in (12, 13, 15):
                    if R in rs: alive[p['line']][R] += 1
                    allseat[p['line']][R].append(rs.get(R, 0))
    print('==', arm)
    for line in sorted(seats):
        print(f'  {line:22s} alive R12 {alive[line][12]/seats[line]:.2f} R15 {alive[line][15]/seats[line]:.2f} | all-seat median (dead=0) R12 {st.median(allseat[line][12])} R15 {st.median(allseat[line][15])}')
