"""Extra reads: R8 leader, early elimination, place distribution, window dependence."""
import os
import statistics
import sys
from collections import Counter

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from qload import ARMS, LINES, SHORT, growth, load, med, seats_of, surv_median  # noqa: E402

DATA = {arm: load(arm) for arm in ARMS}
CANON = ["B", "C", "uncut", "uncut_frozen"]
Q = "line_quilboar_engine"

print("## R8 leader and the winner")
print("| Arm | R8 leader win rate (ties split) | Quilboar is R8 leader | Quilboar wins | Quilboar's R8 rank when it wins (median) | R8 leader win rate in lobbies Quilboar doesn't win | Winner's R8 rank median |")
for arm in CANON:
    L = DATA[arm]
    lead_w, q_lead, q_win, q_rank_win, other_lead, other_n, wrank = 0.0, 0.0, 0, [], 0.0, 0, []
    for lob in L:
        alive = [s for s in lob["seats"] if 8 in s["board"]]
        top = max(s["board"][8] for s in alive)
        leaders = [s for s in alive if s["board"][8] == top]
        winner = [s for s in lob["seats"] if s["place"] == 1][0]
        lw = sum(1 for s in leaders if s is winner) / len(leaders)
        lead_w += lw
        q_lead += sum(1 for s in leaders if s["line"] == Q) / len(leaders)
        ranked = sorted(alive, key=lambda s: -s["board"][8])
        wr = [i for i, s in enumerate(ranked, 1) if s is winner][0]
        wrank.append(wr)
        if winner["line"] == Q:
            q_win += 1
            q_rank_win.append(wr)
        else:
            other_lead += lw
            other_n += 1
    n = len(L)
    print(f"| {arm} | {lead_w / n:.3f} | {q_lead / n:.3f} | {q_win / n:.2f} | {med(q_rank_win)} | {other_lead / other_n:.3f} | {med(wrank)} |")

print("\n## Early elimination: share of seats gone before R10 / R12 / R14, and place distribution")
print("| Arm | Line | gone before R10 | before R12 | before R14 | 1st | 2-4 | 5-8 |")
for arm in CANON:
    L = DATA[arm]
    for line in LINES:
        ss = list(seats_of(L, line))
        n = len(ss)
        g10 = sum(1 for s in ss if 10 not in s["board"]) / n
        g12 = sum(1 for s in ss if 12 not in s["board"]) / n
        g14 = sum(1 for s in ss if 14 not in s["board"]) / n
        p1 = sum(1 for s in ss if s["place"] == 1) / n
        p24 = sum(1 for s in ss if 2 <= s["place"] <= 4) / n
        p58 = sum(1 for s in ss if s["place"] >= 5) / n
        print(f"| {arm} | {SHORT[line]} | {g10:.2f} | {g12:.2f} | {g14:.2f} | {p1:.2f} | {p24:.2f} | {p58:.2f} |")

print("\n## Window dependence of per-line growth (survivor medians, per round)")
print("| Arm | Line | R8-R12 | R12-R15 | R8-R14 | R9-R15 | R10-R16 |")
for arm in CANON:
    L = DATA[arm]
    for line in LINES:
        m = {r: surv_median(L, r, line) for r in range(8, 17)}
        print(f"| {arm} | {SHORT[line]} | {growth(m[8], m[12], 4):.3f} | {growth(m[12], m[15], 3):.3f} | {growth(m[8], m[14], 6):.3f} | {growth(m[9], m[15], 6):.3f} | " +
              (f"{growth(m[10], m[16], 6):.3f}" if m[16] else "-") + " |")

print("\n## Lobby-median growth by window")
print("| Arm | R8-R14 | R9-R15 | R10-R16 | R8-R12 | R12-R15 | survivors at R14 / R16 |")
for arm in CANON + ["B_pre", "uncut_pre"]:
    L = DATA[arm]
    m = {r: surv_median(L, r) for r in range(8, 17)}
    n14 = sum(1 for s in seats_of(L) if 14 in s["board"])
    n16 = sum(1 for s in seats_of(L) if 16 in s["board"])
    print(f"| {arm} | {growth(m[8], m[14], 6):.3f} | {growth(m[9], m[15], 6):.3f} | {growth(m[10], m[16], 6):.3f} | {growth(m[8], m[12], 4):.3f} | {growth(m[12], m[15], 3):.3f} | {n14}/{n16} of {len(L) * 8} |")

print("\n## Quilboar R9 board against Hard and Birds (survivor medians), and units on board R4/R6")
for arm in CANON:
    L = DATA[arm]
    q9, h9, b9 = surv_median(L, 9, Q), surv_median(L, 9, "hard"), surv_median(L, 9, "line_birds_homecoming")
    u4 = statistics.mean(len(s["units"][4]) for s in seats_of(L, Q) if 4 in s["units"])
    u4h = statistics.mean(len(s["units"][4]) for s in seats_of(L, "hard") if 4 in s["units"])
    u6 = statistics.mean(len(s["units"][6]) for s in seats_of(L, Q) if 6 in s["units"])
    u6h = statistics.mean(len(s["units"][6]) for s in seats_of(L, "hard") if 6 in s["units"])
    print(f"{arm}: R9 Quilboar {q9} Hard {h9} Birds {b9}; units R4 Q {u4:.2f} vs Hard {u4h:.2f}; R6 Q {u6:.2f} vs Hard {u6h:.2f}")

print("\n## How many lines pass x1.3 per line (survivor-median R8-R14), per arm")
for arm in CANON:
    L = DATA[arm]
    passing = [SHORT[ln] for ln in LINES if growth(surv_median(L, 8, ln), surv_median(L, 14, ln), 6) >= 1.3]
    print(arm, passing)
